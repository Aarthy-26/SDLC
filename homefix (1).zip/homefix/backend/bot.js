// HomeFix assistant: answers questions about services, prices and bookings.
// Used by the website chat widget AND the WhatsApp bot.
//
// - With ANTHROPIC_API_KEY set: uses Claude for natural conversation.
// - Without it: uses the built-in keyword bot below (free, works offline).

const { getCatalog } = require('./catalog');
const db = require('./db');

const API_KEY = process.env.ANTHROPIC_API_KEY;
const MODEL = process.env.AI_MODEL || 'claude-haiku-5-5';
const CUSTOMER_URL = (process.env.PUBLIC_CUSTOMER_URL || '').replace(/\/$/, '');

const rupee = n => '₹' + Number(n).toLocaleString('en-IN');

// Extra words people use for each item
const SYNONYMS = {
  fan: ['fan', 'pankha', 'ceiling fan', 'regulator'],
  light: ['light', 'bulb', 'tube', 'tubelight', 'led', 'lamp'],
  switch: ['switch', 'socket', 'plug', 'switchboard', 'board'],
  wiring: ['wiring', 'wire', 'short circuit', 'shock', 'spark', 'current'],
  mcb: ['mcb', 'fuse', 'tripping', 'trip', 'breaker'],
  inverter: ['inverter', 'battery', 'ups'],
  ac: ['ac', 'air conditioner', 'aircon', 'cooling'],
  tv: ['tv', 'television', 'led tv', 'smart tv'],
  fridge: ['fridge', 'refrigerator', 'freezer'],
  washing: ['washing', 'washing machine', 'washer'],
  geyser: ['geyser', 'water heater', 'heater', 'hot water'],
  chimney: ['chimney', 'exhaust'],
  microwave: ['microwave', 'oven', 'otg'],
  tap: ['tap', 'faucet', 'shower', 'nal'],
  leak: ['leak', 'leakage', 'seepage', 'dripping', 'water coming'],
  toilet: ['toilet', 'flush', 'commode', 'wc', 'western'],
  basin: ['basin', 'sink', 'wash basin'],
  pipe: ['pipe', 'pipeline', 'fitting'],
  tank: ['tank', 'sintex', 'overhead tank', 'tank cleaning'],
  motor: ['motor', 'pump', 'borewell'],
  bridal: ['bridal', 'bride', 'wedding makeup', 'marriage makeup', 'airbrush', 'hd makeup', 'engagement', 'reception'],
  party: ['party makeup', 'makeup', 'hairstyle', 'saree draping', 'draping'],
  mehendi: ['mehendi', 'mehndi', 'henna'],
};

function link(cat, item) {
  return `/service?cat=${cat.id}&item=${item.id}`;
}

function findItems(text) {
  const t = ' ' + text.toLowerCase() + ' ';
  const hits = [];
  for (const cat of getCatalog()) {
    for (const item of cat.items) {
      const words = SYNONYMS[item.id] || [item.name.toLowerCase()];
      const score = Math.max(...words.map(w => (t.includes(w) ? w.length : 0)));
      if (score > 0) hits.push({ cat, item, score });
    }
  }
  return hits.sort((a, b) => b.score - a.score).slice(0, 2);
}

const FAQ = [
  { keys: ['pay', 'payment', 'upi', 'cash', 'gpay', 'phonepe'], answer: 'You pay after the work is done, by cash or UPI, directly to the professional. You get a full bill on the website.' },
  { keys: ['cancel'], answer: 'You can cancel any time before the work starts: open My Bookings and tap "Cancel booking". It is free.' },
  { keys: ['otp', 'start code', 'code'], answer: 'When you book, you get a 4-digit start code. Share it with the professional only when they reach your home; they need it to start the job.' },
  { keys: ['spare', 'part', 'material'], answer: 'Prices shown are for labour. Spare parts and materials are extra. The professional adds them to your bill, and you approve them on your phone before you pay.' },
  { keys: ['inspection', 'not sure', 'something else', 'dont know', "don't know"], answer: 'Not sure what the problem is? Book "Something else / Not sure" (₹199 inspection). The professional checks it and sends the real price to your phone. If you go ahead, the ₹199 is adjusted in the bill.' },
  { keys: ['time', 'slot', 'when', 'timing', 'today', 'tomorrow'], answer: 'Repairs: 2-hour slots from 8 AM to 8 PM, up to 14 days ahead (book at least 1 hour before). Bridal & mehendi: from 4 AM, up to 6 months ahead, at least 1 day before.' },
  { keys: ['track', 'status', 'where is', 'booking'], answer: 'Open "My Bookings" to see live status, the professional\'s name and phone, and their location when they are on the way.' },
  { keys: ['join', 'partner', 'job', 'work with', 'electrician job', 'plumber job'], answer: 'Want to work with us? Enroll on the HomeFix Partner website. It is free, and you choose which jobs to take.' },
  { keys: ['visit fee', 'visiting'], answer: 'Repairs have a small ₹49 visit fee. Bridal & mehendi have no visit fee.' },
];

function ruleBot(text) {
  const t = text.toLowerCase().trim();
  const links = [];

  if (/^(hi|hello|hey|namaste|hii+|good (morning|evening|afternoon))\b/.test(t) && t.length < 25) {
    return {
      reply: 'Hi! 👋 I\'m Fixy, the HomeFix assistant. Tell me what\'s broken (e.g. "fan not working", "AC not cooling", "water leak") or ask about bridal makeup & mehendi, and I\'ll show you the price.',
      links: [],
    };
  }

  const items = findItems(t);
  const faq = FAQ.find(f => f.keys.some(k => t.includes(k)));

  const parts = [];
  for (const { cat, item } of items) {
    const list = item.services
      .map(s => `• ${s.name}: ${rupee(s.price)}${s.unit ? ` per ${s.unit}` : ''}`)
      .join('\n');
    parts.push(`${item.icon} ${item.name} (${cat.name})\n${list}`);
    links.push({ label: `Book ${item.name}`, url: link(cat, item) });
  }
  if (items.length && items[0].cat.partsNote) parts.push('Spare parts are extra and need your approval.');
  if (faq) parts.push(faq.answer);

  if (!parts.length) {
    const wa = db.data.settings.whatsappNumber;
    return {
      reply: 'Sorry, I didn\'t get that. I can help with electrician, appliance repair, plumber, and bridal makeup & mehendi bookings: prices, timings, payment and cancellation. Try "AC repair price" or "how do I pay?"' +
        (wa ? '\nYou can also chat with our team on WhatsApp.' : ''),
      links: getCatalog().map(c => ({ label: `${c.icon} ${c.name}`, url: `/service?cat=${c.id}` })),
    };
  }
  return { reply: parts.join('\n\n'), links };
}

function catalogForPrompt() {
  return getCatalog().map(c =>
    `## ${c.name} (visit fee ${rupee(c.visitFee)}; book up to ${c.bookingWindowDays} days ahead)\n` +
    c.items.map(i => `- ${i.name}: ` + i.services.map(s => `${s.name} ${rupee(s.price)}${s.unit ? '/' + s.unit : ''}`).join('; ')).join('\n')
  ).join('\n\n');
}

async function aiBot(history) {
  const system = `You are Fixy, the friendly assistant of ${db.data.settings.businessName}, a doorstep home services company in India.
Services: electrician, appliance repair, plumber, bridal makeup & mehendi. (No carpentry.)
Answer briefly (max 6 short lines), in the customer's language (English, Hindi, Telugu, Tamil etc.), with exact prices from the list below.
Rules: prices are labour; spare parts are extra and the customer approves them on their phone. Pay after service by cash/UPI.
"Something else / Not sure" is a ₹199 inspection visit, adjusted in the bill if work is done. The customer gets a 4-digit start code to share when the professional arrives.
Free cancellation before work starts, from My Bookings. Never invent services or prices. To book, tell them to choose the service on the website.

PRICE LIST:
${catalogForPrompt()}`;

  const res = await fetch('https://api.anthropic.com/v1/messages', {
    method: 'POST',
    headers: { 'x-api-key': API_KEY, 'anthropic-version': '2023-06-01', 'content-type': 'application/json' },
    body: JSON.stringify({
      model: MODEL,
      max_tokens: 400,
      system,
      messages: history.slice(-10).map(m => ({ role: m.role === 'bot' ? 'assistant' : 'user', content: String(m.text).slice(0, 1000) })),
    }),
  });
  if (!res.ok) throw new Error(`AI error ${res.status}`);
  const data = await res.json();
  return data.content?.map(c => c.text).join('').trim();
}

// history: [{ role: 'user'|'bot', text }]  (last item is the new user message)
async function answer(history) {
  const last = history[history.length - 1]?.text || '';
  const rules = ruleBot(last);
  if (API_KEY) {
    try {
      const reply = await aiBot(history);
      if (reply) return { reply, links: rules.links.filter(l => !l.label.startsWith('⚡') && !l.label.startsWith('📺')), ai: true };
    } catch (err) {
      console.error('AI bot failed, using built-in bot:', err.message);
    }
  }
  return { ...rules, ai: false };
}

// Plain-text version for WhatsApp (links become full URLs)
async function answerText(history) {
  const { reply, links } = await answer(history);
  const urls = CUSTOMER_URL ? links.slice(0, 3).map(l => `${l.label}: ${CUSTOMER_URL}${l.url}`).join('\n') : '';
  return urls ? `${reply}\n\n${urls}` : reply;
}

module.exports = { answer, answerText };
