// Customer + partner API. Mounted under /api on all three websites,
// so each site talks to its own origin (no CORS setup needed).

const express = require('express');
const bcrypt = require('bcryptjs');
const db = require('./db');
const { getCatalog, getCategory, findService, CATEGORY_IDS } = require('./catalog');
const { signToken, requireAuth, publicUser } = require('./auth');
const { computeBill, partnerEarning, summary } = require('./bill');
const { notify } = require('./notify');
const bot = require('./bot');

const router = express.Router();
const settings = () => db.data.settings;

// ---------- helpers ----------
const clean = v => (typeof v === 'string' ? v.trim() : '');
const isEmail = v => /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(v);
const isPhone = v => /^[6-9]\d{9}$/.test(v); // Indian 10-digit mobile
const isPincode = v => /^\d{6}$/.test(v);
const bad = (res, msg, code = 400) => res.status(code).json({ error: msg });
const now = () => new Date().toISOString();

function todayStr(d = new Date()) {
  return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`;
}

function slotsFor(dateStr, cat) {
  const t = Date.now();
  return cat.slots.map(s => {
    const start = new Date(`${dateStr}T${String(s.startHour).padStart(2, '0')}:00:00`).getTime();
    return { ...s, available: start - t >= cat.minLeadHours * 3600000 };
  });
}

function validateDate(dateStr, cat) {
  if (!/^\d{4}-\d{2}-\d{2}$/.test(dateStr)) return 'Please choose a valid date.';
  const today = new Date(todayStr() + 'T00:00:00');
  const chosen = new Date(dateStr + 'T00:00:00');
  if (isNaN(chosen)) return 'Please choose a valid date.';
  const diffDays = Math.round((chosen - today) / 86400000);
  if (diffDays < 0) return 'Date cannot be in the past.';
  if (diffDays > cat.bookingWindowDays) return `You can book up to ${cat.bookingWindowDays} days in advance.`;
  return null;
}

function validLocation(loc) {
  if (!loc || typeof loc !== 'object') return null;
  const lat = Number(loc.lat), lng = Number(loc.lng);
  if (!Number.isFinite(lat) || !Number.isFinite(lng) || Math.abs(lat) > 90 || Math.abs(lng) > 180) return null;
  return { lat: Math.round(lat * 1e6) / 1e6, lng: Math.round(lng * 1e6) / 1e6 };
}

const otp = () => String(Math.floor(1000 + Math.random() * 9000));

// Turn [{itemId, serviceId, qty}] into priced service lines for one category
function buildServices(categoryId, list) {
  if (!Array.isArray(list) || !list.length) return { error: 'Select at least one service.' };
  if (list.length > 15) return { error: 'Too many services in one booking.' };
  const out = [];
  for (const x of list) {
    const found = findService(categoryId, x.itemId, x.serviceId);
    if (!found) return { error: 'One of the selected services is not valid.' };
    const qty = found.service.unit ? Math.floor(Number(x.qty) || 1) : 1;
    if (qty < 1 || qty > 50) return { error: 'Quantity must be between 1 and 50.' };
    out.push({
      itemId: found.item.id, itemName: found.item.name, itemIcon: found.item.icon,
      serviceId: found.service.id, serviceName: found.service.name,
      unit: found.service.unit, qty, unitPrice: found.service.price,
      duration: found.service.duration, kind: found.service.kind || 'service',
    });
  }
  return { services: out };
}

function buildParts(list) {
  if (list === undefined) return { parts: [] };
  if (!Array.isArray(list) || list.length > 20) return { error: 'Invalid spare parts list.' };
  const parts = [];
  for (const p of list) {
    const name = clean(p.name).slice(0, 80);
    const price = Math.round(Number(p.price));
    if (!name) return { error: 'Each spare part needs a name.' };
    if (!Number.isFinite(price) || price < 1 || price > 200000) return { error: `Enter a valid price for "${name}".` };
    parts.push({ name, price });
  }
  return { parts };
}

function refreshBill(b) {
  b.bill = computeBill(b);
  b.summary = summary(b);
}

function addHistory(b, status, by, note) {
  b.status = status;
  b.history.push({ status, by, at: now(), ...(note ? { note } : {}) });
  b.updatedAt = now();
}

const findCustomer = idv => db.data.customers.find(c => c.id === idv);
const findWorker = idv => db.data.workers.find(w => w.id === idv);

function revisionBill(b) {
  if (!b.revision || b.revision.status !== 'pending') return null;
  return computeBill({ ...b, services: b.revision.services, parts: b.revision.parts });
}

// Booking as seen by the customer
function bookingForCustomer(b) {
  const worker = b.workerId ? findWorker(b.workerId) : null;
  let workerLocation = null;
  if (worker?.location && ['on_the_way', 'in_progress'].includes(b.status)) {
    const ageMin = (Date.now() - new Date(worker.location.at)) / 60000;
    if (ageMin < 15) workerLocation = { lat: worker.location.lat, lng: worker.location.lng, at: worker.location.at };
  }
  return {
    ...b,
    revisionBill: revisionBill(b),
    worker: worker ? {
      name: worker.name, phone: worker.phone, experience: worker.experience,
      rating: worker.rating, ratingCount: worker.ratingCount,
    } : null,
    workerLocation,
  };
}

// Booking as seen by a partner (no OTP; customer phone/full address only after accepting)
function bookingForWorker(b, workerId) {
  const { startOtp, ...rest } = b;
  const mine = b.workerId === workerId;
  const s = settings();
  const customer = findCustomer(b.customerId);
  const cat = getCategory(b.categoryId);
  return {
    ...rest,
    partsNote: cat?.partsNote,
    revisionBill: revisionBill(b),
    earning: s.showPartnerEarnings ? partnerEarning(b.bill, s.partnerShare) : undefined,
    collectAmount: s.showCollectAmount ? b.bill.total : undefined,
    bill: s.showCollectAmount ? b.bill : { lines: b.bill.lines.map(l => ({ ...l, amount: undefined })) },
    customer: customer ? { name: customer.name, phone: mine ? customer.phone : undefined } : null,
    address: mine ? b.address : { area: b.address.area, city: b.address.city, pincode: b.address.pincode },
    location: mine ? b.location : null,
  };
}

function publicWorker(w) {
  const { passwordHash, ...rest } = w;
  return rest;
}

// ---------- public ----------
router.get('/catalog', (req, res) => {
  const s = settings();
  res.json({
    categories: getCatalog(),
    settings: { businessName: s.businessName, whatsappNumber: s.whatsappNumber, supportPhone: s.supportPhone },
  });
});

// Real customer reviews (first name only) for the home page
router.get('/reviews', (req, res) => {
  const reviews = db.data.bookings
    .filter(b => b.rating && b.rating.stars >= 4 && b.rating.comment)
    .sort((a, b) => b.rating.at.localeCompare(a.rating.at))
    .slice(0, 6)
    .map(b => ({
      name: (findCustomer(b.customerId)?.name || 'Customer').split(' ')[0],
      city: b.address.city, stars: b.rating.stars, comment: b.rating.comment,
      service: b.services[0]?.itemName, icon: b.categoryIcon,
    }));
  const rated = db.data.bookings.filter(b => b.rating);
  res.json({
    reviews,
    average: rated.length ? Math.round(rated.reduce((t, b) => t + b.rating.stars, 0) / rated.length * 10) / 10 : null,
    count: rated.length,
    completed: db.data.bookings.filter(b => b.status === 'completed').length,
  });
});

router.get('/slots', (req, res) => {
  const cat = getCategory(clean(req.query.cat)) || getCategory('electrical');
  const date = clean(req.query.date);
  const err = validateDate(date, cat);
  if (err) return bad(res, err);
  res.json({ date, slots: slotsFor(date, cat) });
});

// Chat bot (website widget). Simple per-IP rate limit.
const chatHits = new Map();
router.post('/chat', async (req, res) => {
  const ip = req.ip;
  const minute = Math.floor(Date.now() / 60000);
  const key = `${ip}:${minute}`;
  chatHits.set(key, (chatHits.get(key) || 0) + 1);
  if (chatHits.size > 5000) chatHits.clear();
  if (chatHits.get(key) > 20) return bad(res, 'Too many messages. Please wait a minute.', 429);

  const history = Array.isArray(req.body.history) ? req.body.history.slice(-10) : [];
  const cleanHistory = history
    .filter(m => m && (m.role === 'user' || m.role === 'bot') && typeof m.text === 'string')
    .map(m => ({ role: m.role, text: m.text.slice(0, 1000) }));
  if (!cleanHistory.length || cleanHistory[cleanHistory.length - 1].role !== 'user') return bad(res, 'Empty message.');
  res.json(await bot.answer(cleanHistory));
});

// WhatsApp bot webhook (Meta WhatsApp Cloud API). See README.
router.get('/whatsapp/webhook', (req, res) => {
  const verify = process.env.WHATSAPP_VERIFY_TOKEN;
  if (verify && req.query['hub.mode'] === 'subscribe' && req.query['hub.verify_token'] === verify) {
    return res.status(200).send(String(req.query['hub.challenge'] || ''));
  }
  res.sendStatus(403);
});

router.post('/whatsapp/webhook', async (req, res) => {
  res.sendStatus(200); // reply to Meta immediately
  try {
    const msg = req.body?.entry?.[0]?.changes?.[0]?.value?.messages?.[0];
    if (!msg || msg.type !== 'text') return;
    const { sendWhatsApp } = require('./notify');
    const reply = await bot.answerText([{ role: 'user', text: String(msg.text.body || '').slice(0, 1000) }]);
    await sendWhatsApp(msg.from, reply);
  } catch (err) {
    console.error('WhatsApp webhook error:', err.message);
  }
});

// =====================================================================
// CUSTOMER
// =====================================================================
router.post('/customer/register', async (req, res) => {
  const name = clean(req.body.name);
  const email = clean(req.body.email).toLowerCase();
  const phone = clean(req.body.phone);
  const password = req.body.password || '';

  if (name.length < 2) return bad(res, 'Please enter your full name.');
  if (!isEmail(email)) return bad(res, 'Please enter a valid email.');
  if (!isPhone(phone)) return bad(res, 'Please enter a valid 10-digit mobile number.');
  if (password.length < 6) return bad(res, 'Password must be at least 6 characters.');
  if (db.data.customers.some(c => c.email === email || c.phone === phone)) {
    return bad(res, 'An account with this email or phone already exists. Please log in.', 409);
  }

  const customer = {
    id: db.id(), name, email, phone,
    passwordHash: await bcrypt.hash(password, 10),
    address: null, createdAt: now(),
  };
  db.data.customers.push(customer);
  db.save();
  res.status(201).json({ token: signToken(customer, 'customer'), user: publicUser(customer) });
});

router.post('/customer/login', async (req, res) => {
  const login = clean(req.body.login).toLowerCase();
  const password = req.body.password || '';
  const customer = db.data.customers.find(c => c.email === login || c.phone === login);
  if (!customer || !(await bcrypt.compare(password, customer.passwordHash))) {
    return bad(res, 'Wrong email/phone or password.', 401);
  }
  res.json({ token: signToken(customer, 'customer'), user: publicUser(customer) });
});

router.get('/customer/me', requireAuth('customer'), (req, res) => res.json({ user: publicUser(req.user) }));

router.post('/bookings', requireAuth('customer'), (req, res) => {
  const cat = getCategory(req.body.categoryId);
  if (!cat) return bad(res, 'Please select a valid service.');

  const built = buildServices(cat.id, [{ itemId: req.body.itemId, serviceId: req.body.serviceId, qty: req.body.qty }]);
  if (built.error) return bad(res, built.error);

  const date = clean(req.body.date);
  const dateErr = validateDate(date, cat);
  if (dateErr) return bad(res, dateErr);

  const slot = slotsFor(date, cat).find(s => s.id === req.body.slotId);
  if (!slot) return bad(res, 'Please select a time slot.');
  if (!slot.available) {
    return bad(res, cat.minLeadHours >= 24
      ? 'Please book at least 1 day in advance for this service.'
      : 'That time slot is too soon or has passed. Please pick a later one.');
  }

  const a = req.body.address || {};
  const address = {
    house: clean(a.house), area: clean(a.area), landmark: clean(a.landmark),
    city: clean(a.city), pincode: clean(a.pincode),
  };
  if (!address.house || !address.area || !address.city) return bad(res, 'Please fill in your full address.');
  if (!isPincode(address.pincode)) return bad(res, 'Please enter a valid 6-digit pincode.');

  const notes = clean(req.body.notes).slice(0, 500);
  const isInspection = built.services[0].kind === 'inspection';
  if (isInspection && notes.length < 5) {
    return bad(res, 'Please describe the problem in the notes so the professional knows what to bring.');
  }

  const t = now();
  const booking = {
    id: db.id(),
    ref: db.nextBookingRef(),
    customerId: req.user.id,
    workerId: null,
    categoryId: cat.id, categoryName: cat.name, categoryIcon: cat.icon,
    services: built.services,
    parts: [],
    inspectionFee: isInspection ? built.services[0].unitPrice : 0,
    visitFee: cat.visitFee,
    revision: null,
    date, slotId: slot.id, slotLabel: slot.label,
    address, location: validLocation(req.body.location), notes,
    paymentMode: 'Pay after service (Cash / UPI)',
    startOtp: otp(),
    status: 'pending',
    history: [{ status: 'pending', by: 'customer', at: t }],
    rating: null,
    createdAt: t, updatedAt: t,
  };
  refreshBill(booking);
  db.data.bookings.push(booking);
  req.user.address = address;
  db.save();

  notify({
    to: req.user.phone, name: req.user.name, role: 'customer', bookingRef: booking.ref,
    text: `✅ HomeFix booking ${booking.ref} confirmed\n${booking.summary}\n${booking.date}, ${booking.slotLabel}\nEstimated total: ₹${booking.bill.total}\nStart code: ${booking.startOtp} (share only when the professional arrives)`,
  });
  // Tell online, approved partners with this skill in the same city
  const city = address.city.toLowerCase();
  db.data.workers
    .filter(w => w.online && w.status === 'approved' && w.skills.includes(cat.id) && (w.city || '').toLowerCase() === city)
    .slice(0, 20)
    .forEach(w => notify({
      to: w.phone, name: w.name, role: 'partner', bookingRef: booking.ref,
      text: `🔔 New job ${booking.ref} in ${address.area}, ${address.city}\n${booking.summary}\n${booking.date}, ${booking.slotLabel}\nOpen the partner app to accept.`,
    }));

  res.status(201).json({ booking: bookingForCustomer(booking) });
});

router.get('/bookings/mine', requireAuth('customer'), (req, res) => {
  const list = db.data.bookings
    .filter(b => b.customerId === req.user.id)
    .sort((a, b) => b.createdAt.localeCompare(a.createdAt))
    .map(bookingForCustomer);
  res.json({ bookings: list });
});

function customerBooking(req, res) {
  const b = db.data.bookings.find(x => x.id === req.params.id && x.customerId === req.user.id);
  if (!b) bad(res, 'Booking not found.', 404);
  return b;
}

router.post('/bookings/:id/cancel', requireAuth('customer'), (req, res) => {
  const b = customerBooking(req, res); if (!b) return;
  if (!['pending', 'accepted', 'on_the_way'].includes(b.status)) return bad(res, 'This booking can no longer be cancelled.');
  b.cancelReason = clean(req.body.reason).slice(0, 200) || null;
  b.cancelledBy = 'customer';
  addHistory(b, 'cancelled', 'customer', b.cancelReason);
  db.save();
  const w = b.workerId && findWorker(b.workerId);
  if (w) notify({ to: w.phone, name: w.name, role: 'partner', bookingRef: b.ref, text: `❌ Job ${b.ref} was cancelled by the customer.` });
  res.json({ booking: bookingForCustomer(b) });
});

// Customer approves / rejects the partner's updated work & spare parts
router.post('/bookings/:id/revision/:decision', requireAuth('customer'), (req, res) => {
  const b = customerBooking(req, res); if (!b) return;
  if (!b.revision || b.revision.status !== 'pending') return bad(res, 'There is nothing to approve.');
  const decision = req.params.decision;
  if (!['approve', 'reject'].includes(decision)) return bad(res, 'Invalid choice.');

  if (decision === 'approve') {
    b.services = b.revision.services;
    b.parts = b.revision.parts;
    b.revision.status = 'approved';
    refreshBill(b);
  } else {
    b.revision.status = 'rejected';
  }
  b.revision.decidedAt = now();
  b.history.push({ status: b.status, by: 'customer', at: now(), note: `Updated bill ${decision === 'approve' ? 'approved' : 'rejected'}` });
  db.save();
  const w = findWorker(b.workerId);
  if (w) notify({
    to: w.phone, name: w.name, role: 'partner', bookingRef: b.ref,
    text: decision === 'approve'
      ? `👍 Customer APPROVED the updated bill for ${b.ref}. New total ₹${b.bill.total}. You can continue the work.`
      : `👎 Customer REJECTED the updated bill for ${b.ref}. Do only the originally booked work, or talk to the customer.`,
  });
  res.json({ booking: bookingForCustomer(b) });
});

router.post('/bookings/:id/rate', requireAuth('customer'), (req, res) => {
  const b = customerBooking(req, res); if (!b) return;
  if (b.status !== 'completed') return bad(res, 'You can rate only after the job is completed.');
  if (b.rating) return bad(res, 'You have already rated this booking.');
  const stars = Number(req.body.stars);
  if (!Number.isInteger(stars) || stars < 1 || stars > 5) return bad(res, 'Rating must be 1 to 5 stars.');

  b.rating = { stars, comment: clean(req.body.comment).slice(0, 300), at: now() };
  const worker = findWorker(b.workerId);
  if (worker) {
    const total = worker.rating * worker.ratingCount + stars;
    worker.ratingCount += 1;
    worker.rating = Math.round((total / worker.ratingCount) * 10) / 10;
  }
  db.save();
  res.json({ booking: bookingForCustomer(b) });
});

// =====================================================================
// PARTNER (worker)
// =====================================================================
router.post('/worker/register', async (req, res) => {
  const name = clean(req.body.name);
  const email = clean(req.body.email).toLowerCase();
  const phone = clean(req.body.phone);
  const password = req.body.password || '';
  const city = clean(req.body.city);
  const pincode = clean(req.body.pincode);
  const experience = Number(req.body.experience);
  const skills = Array.isArray(req.body.skills) ? [...new Set(req.body.skills.filter(s => CATEGORY_IDS.includes(s)))] : [];
  const idProofType = clean(req.body.idProofType);
  const idProofLast4 = clean(req.body.idProofLast4);
  const about = clean(req.body.about).slice(0, 300);

  if (name.length < 2) return bad(res, 'Please enter your full name.');
  if (!isPhone(phone)) return bad(res, 'Please enter a valid 10-digit mobile number.');
  if (!isEmail(email)) return bad(res, 'Please enter a valid email.');
  if (password.length < 6) return bad(res, 'Password must be at least 6 characters.');
  if (!skills.length) return bad(res, 'Select at least one skill.');
  if (!Number.isFinite(experience) || experience < 0 || experience > 50) return bad(res, 'Please enter your years of experience.');
  if (!city) return bad(res, 'Please enter your city.');
  if (!isPincode(pincode)) return bad(res, 'Please enter a valid 6-digit pincode.');
  if (!['Aadhaar', 'PAN', 'Driving Licence', 'Voter ID'].includes(idProofType)) return bad(res, 'Please select an ID proof type.');
  if (!/^[A-Za-z0-9]{4}$/.test(idProofLast4)) return bad(res, 'Enter the last 4 characters of your ID number.');
  if (!req.body.agree) return bad(res, 'Please accept the partner terms.');
  if (db.data.workers.some(w => w.email === email || w.phone === phone)) {
    return bad(res, 'A partner account with this email or phone already exists. Please log in.', 409);
  }

  const worker = {
    id: db.id(), name, email, phone,
    passwordHash: await bcrypt.hash(password, 10),
    skills, experience, city, pincode, about,
    idProofType, idProofLast4: idProofLast4.toUpperCase(),
    status: settings().requirePartnerApproval ? 'pending_approval' : 'approved',
    online: true, location: null,
    rating: 0, ratingCount: 0,
    createdAt: now(),
  };
  db.data.workers.push(worker);
  db.save();
  res.status(201).json({ token: signToken(worker, 'worker'), user: publicUser(worker) });
});

router.post('/worker/login', async (req, res) => {
  const login = clean(req.body.login).toLowerCase();
  const password = req.body.password || '';
  const worker = db.data.workers.find(w => w.email === login || w.phone === login);
  if (!worker || !(await bcrypt.compare(password, worker.passwordHash))) {
    return bad(res, 'Wrong email/phone or password.', 401);
  }
  if (worker.status === 'blocked') return bad(res, 'Your partner account is blocked. Please contact support.', 403);
  res.json({ token: signToken(worker, 'worker'), user: publicUser(worker) });
});

// Blocked partners are logged out on their next request
function activeWorker(req, res, next) {
  if (req.user.status === 'blocked') return bad(res, 'Your partner account is blocked. Please contact support.', 401);
  next();
}
const worker = [requireAuth('worker'), activeWorker];

router.get('/worker/me', worker, (req, res) => {
  const s = settings();
  res.json({ user: publicUser(req.user), settings: { showPartnerEarnings: s.showPartnerEarnings, showCollectAmount: s.showCollectAmount } });
});

router.patch('/worker/me', worker, (req, res) => {
  const w = req.user;
  if (typeof req.body.online === 'boolean') w.online = req.body.online;
  if (Array.isArray(req.body.skills)) {
    const skills = [...new Set(req.body.skills.filter(s => CATEGORY_IDS.includes(s)))];
    if (!skills.length) return bad(res, 'Select at least one skill.');
    w.skills = skills;
  }
  if (req.body.city !== undefined) {
    const city = clean(req.body.city);
    if (!city) return bad(res, 'City cannot be empty.');
    w.city = city;
  }
  if (req.body.about !== undefined) w.about = clean(req.body.about).slice(0, 300);
  db.save();
  res.json({ user: publicUser(w) });
});

// Live location from the partner's phone (sent every ~30s while online)
router.post('/worker/location', worker, (req, res) => {
  const loc = validLocation(req.body);
  if (!loc) return bad(res, 'Invalid location.');
  const acc = Number(req.body.accuracy);
  req.user.location = { ...loc, accuracy: Number.isFinite(acc) ? Math.round(acc) : null, at: now() };
  db.save();
  res.json({ ok: true });
});

router.get('/jobs/available', worker, (req, res) => {
  const w = req.user;
  if (w.status !== 'approved') return res.json({ jobs: [], notApproved: true });
  if (!w.online) return res.json({ jobs: [], offline: true });
  const city = (w.city || '').toLowerCase();
  const today = todayStr();
  const jobs = db.data.bookings
    .filter(b => b.status === 'pending' && w.skills.includes(b.categoryId) && b.date >= today)
    .sort((a, b) => {
      const ac = a.address.city.toLowerCase() === city ? 0 : 1;
      const bc = b.address.city.toLowerCase() === city ? 0 : 1;
      return ac - bc || (a.date + a.slotId).localeCompare(b.date + b.slotId);
    })
    .map(b => bookingForWorker(b, w.id));
  res.json({ jobs });
});

router.get('/jobs/mine', worker, (req, res) => {
  const jobs = db.data.bookings
    .filter(b => b.workerId === req.user.id)
    .sort((a, b) => (b.date + b.slotId).localeCompare(a.date + a.slotId))
    .map(b => bookingForWorker(b, req.user.id));
  res.json({ jobs });
});

router.post('/jobs/:id/accept', worker, (req, res) => {
  const w = req.user;
  const b = db.data.bookings.find(x => x.id === req.params.id);
  if (!b) return bad(res, 'Job not found.', 404);
  if (w.status !== 'approved') return bad(res, 'Your account is waiting for approval.', 403);
  if (b.status !== 'pending' || b.workerId) return bad(res, 'Sorry, this job was already taken or cancelled.', 409);
  if (!w.skills.includes(b.categoryId)) return bad(res, 'This job does not match your skills.', 403);
  if (!w.online) return bad(res, 'Go online to accept jobs.');
  const clash = db.data.bookings.some(x =>
    x.workerId === w.id && x.date === b.date && x.slotId === b.slotId &&
    ['accepted', 'on_the_way', 'in_progress'].includes(x.status));
  if (clash) return bad(res, 'You already have a job in this time slot.', 409);

  b.workerId = w.id;
  addHistory(b, 'accepted', 'partner');
  db.save();
  const c = findCustomer(b.customerId);
  if (c) notify({ to: c.phone, name: c.name, role: 'customer', bookingRef: b.ref, text: `👷 ${w.name} (${w.experience} yrs exp) will handle your booking ${b.ref} on ${b.date}, ${b.slotLabel}. Phone: ${w.phone}` });
  res.json({ job: bookingForWorker(b, w.id) });
});

function myJob(req, res) {
  const b = db.data.bookings.find(x => x.id === req.params.id && x.workerId === req.user.id);
  if (!b) bad(res, 'Job not found.', 404);
  return b;
}

// Status flow: accepted -> on_the_way -> in_progress (needs OTP) -> completed
router.post('/jobs/:id/status', worker, (req, res) => {
  const w = req.user;
  const b = myJob(req, res); if (!b) return;
  const next = req.body.status;
  const allowed = { accepted: ['on_the_way'], on_the_way: ['in_progress'], in_progress: ['completed'] };
  if (!(allowed[b.status] || []).includes(next)) return bad(res, `Cannot change status from "${b.status}" to "${next}".`);

  if (next === 'in_progress' && clean(req.body.otp) !== b.startOtp) {
    return bad(res, 'Wrong start code. Ask the customer for the 4-digit code shown in their booking.');
  }
  if (next === 'completed') {
    if (b.revision?.status === 'pending') return bad(res, 'Wait for the customer to approve or reject the updated bill first.');
    b.completedAt = now();
  }
  addHistory(b, next, 'partner');
  db.save();

  const c = findCustomer(b.customerId);
  const msgs = {
    on_the_way: `🛵 ${w.name} is on the way for booking ${b.ref}. Keep your start code ready: ${b.startOtp}`,
    in_progress: `🔧 Work started for booking ${b.ref}.`,
    completed: `🎉 Booking ${b.ref} completed. Total to pay: ₹${b.bill.total} (cash/UPI). Please rate ${w.name} on the website.`,
  };
  if (c) notify({ to: c.phone, name: c.name, role: 'customer', bookingRef: b.ref, text: msgs[next] });
  res.json({ job: bookingForWorker(b, w.id) });
});

// Partner updates the work found on site and/or adds spare parts -> customer must approve
router.post('/jobs/:id/revision', worker, (req, res) => {
  const b = myJob(req, res); if (!b) return;
  if (b.status !== 'in_progress') return bad(res, 'You can update the bill only after starting the job with the customer\'s code.');
  const built = buildServices(b.categoryId, req.body.services);
  if (built.error) return bad(res, built.error);
  const parts = buildParts(req.body.parts);
  if (parts.error) return bad(res, parts.error);

  b.revision = {
    services: built.services, parts: parts.parts,
    note: clean(req.body.note).slice(0, 300),
    status: 'pending', at: now(),
  };
  b.history.push({ status: b.status, by: 'partner', at: now(), note: 'Sent updated bill for approval' });
  db.save();
  const nb = revisionBill(b);
  const c = findCustomer(b.customerId);
  if (c) notify({
    to: c.phone, name: c.name, role: 'customer', bookingRef: b.ref,
    text: `📝 Your professional updated the work for ${b.ref}.\nNew total: ₹${nb.total}${b.revision.note ? `\nNote: ${b.revision.note}` : ''}\nOpen My Bookings to APPROVE or REJECT.`,
  });
  res.json({ job: bookingForWorker(b, req.user.id) });
});

// Partner cancels: "can't come" gives the job back; other reasons cancel the booking
const PARTNER_CANCEL_REASONS = {
  cant_come: 'Partner cannot come',
  customer_not_available: 'Customer not available at the address',
  customer_not_reachable: 'Customer not reachable on phone',
  wrong_address: 'Wrong / incomplete address',
  customer_refused: 'Customer did not want the service',
  other: 'Other reason',
};

router.post('/jobs/:id/cancel', worker, (req, res) => {
  const w = req.user;
  const b = myJob(req, res); if (!b) return;
  const reason = req.body.reason;
  if (!PARTNER_CANCEL_REASONS[reason]) return bad(res, 'Please choose a reason.');
  const note = clean(req.body.note).slice(0, 200);
  const c = findCustomer(b.customerId);

  if (reason === 'cant_come') {
    if (!['accepted', 'on_the_way'].includes(b.status)) return bad(res, 'You can only give back a job before starting it.');
    b.workerId = null;
    w.cancelCount = (w.cancelCount || 0) + 1;
    addHistory(b, 'pending', 'partner', `Released: ${note || PARTNER_CANCEL_REASONS[reason]}`);
    db.save();
    if (c) notify({ to: c.phone, name: c.name, role: 'customer', bookingRef: b.ref, text: `ℹ️ Your professional for ${b.ref} can't come. We are finding another professional for the same time.` });
    return res.json({ released: true });
  }

  if (!['accepted', 'on_the_way', 'in_progress'].includes(b.status)) return bad(res, 'This job cannot be cancelled now.');
  if (reason === 'other' && note.length < 3) return bad(res, 'Please write the reason.');
  b.cancelledBy = 'partner';
  w.cancelCount = (w.cancelCount || 0) + 1;
  b.cancelReason = PARTNER_CANCEL_REASONS[reason] + (note ? `: ${note}` : '');
  addHistory(b, 'cancelled', 'partner', b.cancelReason);
  db.save();
  if (c) notify({ to: c.phone, name: c.name, role: 'customer', bookingRef: b.ref, text: `❌ Booking ${b.ref} was cancelled by the professional. Reason: ${b.cancelReason}. You can book again any time.` });
  res.json({ cancelled: true });
});

router.get('/worker/earnings', worker, (req, res) => {
  const s = settings();
  const done = db.data.bookings.filter(b => b.workerId === req.user.id && b.status === 'completed');
  const today = todayStr();
  const month = today.slice(0, 7);
  const earn = b => partnerEarning(b.bill, s.partnerShare);
  const sum = list => list.reduce((t, b) => t + earn(b), 0);
  const show = s.showPartnerEarnings;
  res.json({
    showAmounts: show,
    share: show ? s.partnerShare : undefined,
    totalJobs: done.length,
    todayJobs: done.filter(b => (b.completedAt || '').startsWith(today)).length,
    monthJobs: done.filter(b => (b.completedAt || '').startsWith(month)).length,
    total: show ? sum(done) : undefined,
    today: show ? sum(done.filter(b => (b.completedAt || '').startsWith(today))) : undefined,
    thisMonth: show ? sum(done.filter(b => (b.completedAt || '').startsWith(month))) : undefined,
    recent: done
      .sort((a, b) => (b.completedAt || '').localeCompare(a.completedAt || ''))
      .slice(0, 30)
      .map(b => ({ ref: b.ref, summary: b.summary, date: b.date, amount: show ? earn(b) : undefined, rating: b.rating })),
  });
});

module.exports = router;
module.exports.helpers = { bookingForCustomer, refreshBill, addHistory, publicWorker, PARTNER_CANCEL_REASONS };
