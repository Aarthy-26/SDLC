// Tiny JSON-file database. No native modules, so it runs anywhere (Windows/Mac/Linux).
// Data lives in data/db.json. For production, swap this for PostgreSQL/MySQL/MongoDB
// by re-implementing the same few functions.

const fs = require('fs');
const path = require('path');
const crypto = require('crypto');

const DATA_DIR = path.join(__dirname, '..', 'data');
const DB_FILE = path.join(DATA_DIR, 'db.json');
const SCHEMA_VERSION = 2;

const DEFAULT_SETTINGS = {
  businessName: 'HomeFix',
  whatsappNumber: '',          // e.g. 919876543210 (country code + number), shown as the WhatsApp button
  supportPhone: '',
  partnerShare: 0.8,           // partner keeps 80% of service charges (+100% of spare parts)
  showPartnerEarnings: false,  // hide "your earning" numbers on the partner website
  showCollectAmount: true,     // show partners how much to collect (needed for cash payments)
  requirePartnerApproval: true // new partners must be approved by the owner before getting jobs
};

const EMPTY = () => ({
  version: SCHEMA_VERSION,
  customers: [], workers: [], bookings: [], notifications: [],
  settings: { ...DEFAULT_SETTINGS },
  priceOverrides: {},
  counters: { booking: 1000 },
});

let state;

function load() {
  if (!fs.existsSync(DATA_DIR)) fs.mkdirSync(DATA_DIR, { recursive: true });
  if (!fs.existsSync(DB_FILE)) {
    state = EMPTY();
    save();
    return;
  }
  const raw = JSON.parse(fs.readFileSync(DB_FILE, 'utf8'));
  if ((raw.version || 1) < SCHEMA_VERSION) {
    // Old data format from version 1: keep a backup and start fresh.
    const backup = path.join(DATA_DIR, `db.v${raw.version || 1}.backup.json`);
    fs.copyFileSync(DB_FILE, backup);
    console.log(`Old database format found. Backed up to ${backup} and started a fresh database.`);
    state = EMPTY();
    save();
    return;
  }
  state = { ...EMPTY(), ...raw };
  state.settings = { ...DEFAULT_SETTINGS, ...(raw.settings || {}) };
}

function save() {
  const tmp = DB_FILE + '.tmp';
  fs.writeFileSync(tmp, JSON.stringify(state, null, 2));
  fs.renameSync(tmp, DB_FILE); // atomic replace so a crash never leaves a half-written file
}

const id = () => crypto.randomUUID();

function nextBookingRef() {
  state.counters.booking += 1;
  return 'HF' + state.counters.booking;
}

load();

module.exports = {
  get data() { return state; },
  save,
  id,
  nextBookingRef,
};
