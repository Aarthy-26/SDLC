// Owner / admin API. Mounted at /api/admin on the Owner website only.
// Login: ADMIN_USERNAME / ADMIN_PASSWORD environment variables
// (defaults: admin / admin123 — CHANGE THESE before going live).

const express = require('express');
const jwt = require('jsonwebtoken');
const crypto = require('crypto');
const db = require('./db');
const { getCatalog, setOverrides } = require('./catalog');
const { partnerEarning } = require('./bill');
const { notify, whatsappEnabled } = require('./notify');
const { helpers } = require('./api');

const router = express.Router();
const JWT_SECRET = process.env.JWT_SECRET || 'change-this-secret-in-production';
const ADMIN_USER = process.env.ADMIN_USERNAME || 'admin';
const ADMIN_PASS = process.env.ADMIN_PASSWORD || 'admin123';

const bad = (res, msg, code = 400) => res.status(code).json({ error: msg });
const clean = v => (typeof v === 'string' ? v.trim() : '');

function safeEqual(a, b) {
  const ha = crypto.createHash('sha256').update(String(a)).digest();
  const hb = crypto.createHash('sha256').update(String(b)).digest();
  return crypto.timingSafeEqual(ha, hb);
}

// slow down password guessing
const failed = new Map();
router.post('/login', (req, res) => {
  const ip = req.ip;
  const f = failed.get(ip) || { n: 0, until: 0 };
  if (f.until > Date.now()) return bad(res, 'Too many wrong attempts. Try again in a few minutes.', 429);
  const ok = safeEqual(clean(req.body.username), ADMIN_USER) & safeEqual(req.body.password || '', ADMIN_PASS);
  if (!ok) {
    f.n += 1;
    if (f.n >= 5) { f.until = Date.now() + 5 * 60000; f.n = 0; }
    failed.set(ip, f);
    return bad(res, 'Wrong username or password.', 401);
  }
  failed.delete(ip);
  res.json({ token: jwt.sign({ sub: 'admin', role: 'admin' }, JWT_SECRET, { expiresIn: '12h' }), usingDefaultPassword: ADMIN_PASS === 'admin123' });
});

router.use((req, res, next) => {
  const h = req.headers.authorization || '';
  try {
    const p = jwt.verify(h.startsWith('Bearer ') ? h.slice(7) : '', JWT_SECRET);
    if (p.role !== 'admin') throw new Error();
    next();
  } catch {
    bad(res, 'Please log in.', 401);
  }
});

const customerName = id => db.data.customers.find(c => c.id === id);
const workerById = id => db.data.workers.find(w => w.id === id);
const todayStr = () => { const d = new Date(); return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`; };

function bookingRow(b) {
  const c = customerName(b.customerId);
  const w = b.workerId ? workerById(b.workerId) : null;
  return {
    ...b,
    customer: c ? { name: c.name, phone: c.phone } : null,
    worker: w ? { id: w.id, name: w.name, phone: w.phone } : null,
  };
}

// ---------- overview ----------
router.get('/overview', (req, res) => {
  const B = db.data.bookings;
  const today = todayStr();
  const done = B.filter(b => b.status === 'completed');
  const s = db.data.settings;
  const revenue = done.reduce((t, b) => t + b.bill.total, 0);
  const partnerPay = done.reduce((t, b) => t + partnerEarning(b.bill, s.partnerShare), 0);
  const byCat = {};
  for (const b of B) byCat[b.categoryName] = (byCat[b.categoryName] || 0) + 1;
  res.json({
    bookingsTotal: B.length,
    bookingsToday: B.filter(b => b.createdAt.startsWith(today)).length,
    jobsToday: B.filter(b => b.date === today && b.status !== 'cancelled').length,
    pending: B.filter(b => b.status === 'pending').length,
    active: B.filter(b => ['accepted', 'on_the_way', 'in_progress'].includes(b.status)).length,
    approvalsWaiting: B.filter(b => b.revision?.status === 'pending').length,
    completed: done.length,
    cancelled: B.filter(b => b.status === 'cancelled').length,
    revenue, partnerPay, platformEarning: revenue - partnerPay,
    customers: db.data.customers.length,
    partners: db.data.workers.length,
    partnersOnline: db.data.workers.filter(w => w.online && w.status === 'approved').length,
    partnersPending: db.data.workers.filter(w => w.status === 'pending_approval').length,
    byCategory: byCat,
    whatsappConnected: whatsappEnabled(),
    aiConnected: Boolean(process.env.ANTHROPIC_API_KEY),
  });
});

// ---------- live map ----------
router.get('/live', (req, res) => {
  const active = db.data.bookings.filter(b => ['pending', 'accepted', 'on_the_way', 'in_progress'].includes(b.status));
  res.json({
    partners: db.data.workers
      .filter(w => w.location && w.status === 'approved')
      .map(w => ({
        id: w.id, name: w.name, phone: w.phone, skills: w.skills, online: w.online, location: w.location,
        activeJob: (() => { const j = active.find(b => b.workerId === w.id && ['on_the_way', 'in_progress'].includes(b.status)); return j ? { ref: j.ref, status: j.status } : null; })(),
      })),
    bookings: active.map(b => {
      const c = customerName(b.customerId);
      const w = b.workerId ? workerById(b.workerId) : null;
      return {
        id: b.id, ref: b.ref, status: b.status, summary: b.summary, date: b.date, slotLabel: b.slotLabel,
        address: b.address, location: b.location,
        customer: c ? { name: c.name, phone: c.phone } : null,
        worker: w ? { name: w.name, phone: w.phone } : null,
      };
    }),
  });
});

// ---------- bookings ----------
router.get('/bookings', (req, res) => {
  const status = clean(req.query.status);
  const q = clean(req.query.q).toLowerCase();
  let list = db.data.bookings.map(bookingRow);
  if (status === 'active') list = list.filter(b => ['accepted', 'on_the_way', 'in_progress'].includes(b.status));
  else if (status) list = list.filter(b => b.status === status);
  if (q) list = list.filter(b => [b.ref, b.summary, b.customer?.name, b.customer?.phone, b.worker?.name, b.address.city, b.address.area]
    .some(v => String(v || '').toLowerCase().includes(q)));
  list.sort((a, b) => b.createdAt.localeCompare(a.createdAt));
  res.json({ bookings: list.slice(0, 300) });
});

router.post('/bookings/:id/cancel', (req, res) => {
  const b = db.data.bookings.find(x => x.id === req.params.id);
  if (!b) return bad(res, 'Booking not found.', 404);
  if (['completed', 'cancelled'].includes(b.status)) return bad(res, 'This booking is already closed.');
  b.cancelledBy = 'owner';
  b.cancelReason = clean(req.body.reason).slice(0, 200) || 'Cancelled by HomeFix';
  helpers.addHistory(b, 'cancelled', 'owner', b.cancelReason);
  db.save();
  const c = customerName(b.customerId);
  if (c) notify({ to: c.phone, name: c.name, role: 'customer', bookingRef: b.ref, text: `❌ Booking ${b.ref} was cancelled by HomeFix. Reason: ${b.cancelReason}` });
  res.json({ booking: bookingRow(b) });
});

// Assign / reassign a partner manually
router.post('/bookings/:id/assign', (req, res) => {
  const b = db.data.bookings.find(x => x.id === req.params.id);
  if (!b) return bad(res, 'Booking not found.', 404);
  if (!['pending', 'accepted'].includes(b.status)) return bad(res, 'You can assign only before the partner starts travelling.');
  const w = workerById(req.body.workerId);
  if (!w || w.status !== 'approved') return bad(res, 'Choose an approved partner.');
  if (!w.skills.includes(b.categoryId)) return bad(res, `${w.name} does not have the skill for this job.`);
  b.workerId = w.id;
  helpers.addHistory(b, 'accepted', 'owner', `Assigned to ${w.name}`);
  db.save();
  notify({ to: w.phone, name: w.name, role: 'partner', bookingRef: b.ref, text: `📌 HomeFix assigned you job ${b.ref}: ${b.summary}, ${b.date} ${b.slotLabel}, ${b.address.area}, ${b.address.city}.` });
  const c = customerName(b.customerId);
  if (c) notify({ to: c.phone, name: c.name, role: 'customer', bookingRef: b.ref, text: `👷 ${w.name} will handle your booking ${b.ref}. Phone: ${w.phone}` });
  res.json({ booking: bookingRow(b) });
});

// ---------- partners ----------
router.get('/partners', (req, res) => {
  const B = db.data.bookings;
  res.json({
    partners: db.data.workers
      .map(w => ({
        ...helpers.publicWorker(w),
        jobsDone: B.filter(b => b.workerId === w.id && b.status === 'completed').length,
        jobsActive: B.filter(b => b.workerId === w.id && ['accepted', 'on_the_way', 'in_progress'].includes(b.status)).length,
        cancels: w.cancelCount || 0,
      }))
      .sort((a, b) => (a.status === 'pending_approval' ? -1 : 0) - (b.status === 'pending_approval' ? -1 : 0) || b.createdAt.localeCompare(a.createdAt)),
  });
});

router.post('/partners/:id/status', (req, res) => {
  const w = workerById(req.params.id);
  if (!w) return bad(res, 'Partner not found.', 404);
  const status = req.body.status;
  if (!['approved', 'blocked', 'pending_approval'].includes(status)) return bad(res, 'Invalid status.');
  w.status = status;
  if (status === 'blocked') w.online = false;
  db.save();
  if (status === 'approved') notify({ to: w.phone, name: w.name, role: 'partner', text: `🎉 Welcome to HomeFix Partner, ${w.name}! Your account is approved. Go online in the partner app to start getting jobs.` });
  res.json({ partner: helpers.publicWorker(w) });
});

// ---------- customers ----------
router.get('/customers', (req, res) => {
  const B = db.data.bookings;
  res.json({
    customers: db.data.customers.map(c => {
      const { passwordHash, ...rest } = c;
      const mine = B.filter(b => b.customerId === c.id);
      return { ...rest, bookings: mine.length, spent: mine.filter(b => b.status === 'completed').reduce((t, b) => t + b.bill.total, 0) };
    }).sort((a, b) => b.createdAt.localeCompare(a.createdAt)),
  });
});

// ---------- settings ----------
router.get('/settings', (req, res) => res.json({ settings: db.data.settings }));

router.put('/settings', (req, res) => {
  const s = db.data.settings;
  const b = req.body || {};
  if (b.businessName !== undefined) {
    const v = clean(b.businessName).slice(0, 40);
    if (!v) return bad(res, 'Business name cannot be empty.');
    s.businessName = v;
  }
  if (b.whatsappNumber !== undefined) {
    const v = String(b.whatsappNumber).replace(/\D/g, '');
    if (v && (v.length < 10 || v.length > 15)) return bad(res, 'WhatsApp number must include country code, e.g. 919876543210.');
    s.whatsappNumber = v.length === 10 ? '91' + v : v;
  }
  if (b.supportPhone !== undefined) s.supportPhone = clean(b.supportPhone).slice(0, 20);
  if (b.partnerShare !== undefined) {
    const v = Number(b.partnerShare);
    if (!Number.isFinite(v) || v < 0.3 || v > 1) return bad(res, 'Partner share must be between 30% and 100%.');
    s.partnerShare = Math.round(v * 100) / 100;
  }
  for (const k of ['showPartnerEarnings', 'showCollectAmount', 'requirePartnerApproval']) {
    if (typeof b[k] === 'boolean') s[k] = b[k];
  }
  db.save();
  res.json({ settings: s });
});

// ---------- prices ----------
router.get('/prices', (req, res) => res.json({ categories: getCatalog(), overrides: db.data.priceOverrides }));

router.put('/prices', (req, res) => {
  const incoming = req.body?.prices;
  if (!incoming || typeof incoming !== 'object') return bad(res, 'No prices sent.');
  const valid = new Set();
  for (const c of getCatalog()) {
    valid.add(`${c.id}.__visit`);
    for (const i of c.items) for (const s of i.services) valid.add(`${c.id}.${i.id}.${s.id}`);
  }
  for (const [key, val] of Object.entries(incoming)) {
    if (!valid.has(key)) return bad(res, `Unknown price key: ${key}`);
    const n = Math.round(Number(val));
    if (!Number.isFinite(n) || n < 0 || n > 500000) return bad(res, `Invalid price for ${key}.`);
    db.data.priceOverrides[key] = n;
  }
  setOverrides(db.data.priceOverrides);
  db.save();
  res.json({ categories: getCatalog() });
});

router.post('/prices/reset', (req, res) => {
  db.data.priceOverrides = {};
  setOverrides({});
  db.save();
  res.json({ categories: getCatalog() });
});

// ---------- notifications ----------
router.get('/notifications', (req, res) => {
  res.json({ notifications: db.data.notifications.slice(0, 200), whatsappConnected: whatsappEnabled() });
});

// make sure overrides saved earlier are applied at startup
setOverrides(db.data.priceOverrides);

module.exports = router;
