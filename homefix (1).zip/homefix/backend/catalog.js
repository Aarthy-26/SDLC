// =====================================================================
// SERVICE CATALOG
// category -> item -> service options
//
// price  = price for ONE unit (e.g. one fan, one bulb). Customers choose
//          the quantity, and the total = price x quantity.
// unit   = what one unit is ("fan", "light"...). null = flat price for the
//          whole job (e.g. wiring inspection, leak detection).
// kind   = "inspection" for the "Something else" visit. If the worker then
//          does real work, the inspection fee is adjusted in the final bill.
//
// The owner can also change any price from the Owner panel (Prices tab)
// without editing this file.
// =====================================================================

const svc = (id, name, price, duration, unit = null, extra = {}) => ({ id, name, price, duration, unit, ...extra });

const STANDARD_SLOTS = [
  { id: '08-10', label: '8:00 AM - 10:00 AM', startHour: 8 },
  { id: '10-12', label: '10:00 AM - 12:00 PM', startHour: 10 },
  { id: '12-14', label: '12:00 PM - 2:00 PM', startHour: 12 },
  { id: '14-16', label: '2:00 PM - 4:00 PM', startHour: 14 },
  { id: '16-18', label: '4:00 PM - 6:00 PM', startHour: 16 },
  { id: '18-20', label: '6:00 PM - 8:00 PM', startHour: 18 },
];

const BEAUTY_SLOTS = [
  { id: '04-07', label: '4:00 AM - 7:00 AM (early muhurtham)', startHour: 4 },
  { id: '07-10', label: '7:00 AM - 10:00 AM', startHour: 7 },
  { id: '10-13', label: '10:00 AM - 1:00 PM', startHour: 10 },
  { id: '13-16', label: '1:00 PM - 4:00 PM', startHour: 13 },
  { id: '16-19', label: '4:00 PM - 7:00 PM', startHour: 16 },
  { id: '19-22', label: '7:00 PM - 10:00 PM', startHour: 19 },
];

const CATALOG = [
  {
    id: 'electrical',
    name: 'Electrician',
    icon: '⚡',
    color: '#ffb703',
    tagline: 'Fans, lights, switches, wiring & MCB',
    visitFee: 49,
    partsNote: 'Spare parts (new fan, bulb, switch, wire etc.) are extra and charged only after your approval.',
    hasInspection: true,
    bookingWindowDays: 14,
    minLeadHours: 1,
    slots: STANDARD_SLOTS,
    items: [
      { id: 'fan', name: 'Ceiling / Wall Fan', icon: '🌀', services: [
        svc('install', 'Installation / Replacement', 249, '45 min', 'fan'),
        svc('uninstall', 'Uninstallation', 149, '30 min', 'fan'),
        svc('repair', 'Repair (noise, speed, regulator replacement, not working)', 299, '1 hr', 'fan'),
      ]},
      { id: 'light', name: 'Lights, Bulbs & Tube lights', icon: '💡', services: [
        svc('install', 'Installation / Replacement', 129, '20 min', 'light'),
        svc('uninstall', 'Uninstallation', 99, '15 min', 'light'),
        svc('repair', 'Repair (flickering, choke, holder)', 179, '30 min', 'light'),
      ]},
      { id: 'switch', name: 'Switch, Socket & Switchboard', icon: '🔌', services: [
        svc('install', 'Switch / socket installation / replacement', 119, '20 min', 'point'),
        svc('repair', 'Switch / socket repair', 99, '20 min', 'point'),
        svc('board', 'Switchboard installation / replacement', 349, '1 hr', 'board'),
      ]},
      { id: 'wiring', name: 'House Wiring', icon: '🧵', services: [
        svc('inspect', 'Inspection & fault finding', 199, '1 hr'),
        svc('repair', 'Short-circuit / wiring repair', 499, '2 hr'),
        svc('new', 'New point wiring', 399, '1.5 hr', 'point'),
      ]},
      { id: 'mcb', name: 'MCB (Miniature Circuit Breaker) / Fuse', icon: '🧯', services: [
        svc('install', 'MCB installation / replacement', 249, '45 min', 'MCB'),
        svc('repair', 'MCB / fuse repair (keeps tripping)', 199, '30 min', 'MCB'),
      ]},
      { id: 'inverter', name: 'Inverter & Battery', icon: '🔋', services: [
        svc('install', 'Installation / Replacement', 499, '1.5 hr', 'inverter'),
        svc('uninstall', 'Uninstallation', 299, '45 min', 'inverter'),
        svc('repair', 'Repair / Check-up', 399, '1 hr', 'inverter'),
      ]},
    ],
  },
  {
    id: 'appliances',
    name: 'Appliance Repair',
    icon: '📺',
    color: '#4cc9f0',
    tagline: 'AC, TV, fridge, washing machine & more',
    visitFee: 49,
    partsNote: 'Spare parts (PCB, capacitor, compressor, gas etc.) are extra and charged only after your approval.',
    hasInspection: true,
    bookingWindowDays: 14,
    minLeadHours: 1,
    slots: STANDARD_SLOTS,
    items: [
      { id: 'ac', name: 'Air Conditioner', icon: '❄️', services: [
        svc('install', 'Installation / Replacement (split / window)', 1499, '2.5 hr', 'AC'),
        svc('uninstall', 'Uninstallation', 699, '1 hr', 'AC'),
        svc('service', 'Service / Deep cleaning', 599, '1 hr', 'AC'),
        svc('repair', 'Repair (no cooling, water leakage, noise)', 499, '1.5 hr', 'AC'),
        svc('gas', 'Gas refill', 2499, '1.5 hr', 'AC'),
      ]},
      { id: 'tv', name: 'Television', icon: '📺', services: [
        svc('install', 'Wall mount installation / Replacement', 499, '1 hr', 'TV'),
        svc('uninstall', 'Uninstallation', 299, '30 min', 'TV'),
        svc('repair', 'Repair (display, sound, power)', 449, '1.5 hr', 'TV'),
      ]},
      { id: 'fridge', name: 'Refrigerator', icon: '🧊', services: [
        svc('repair', 'Repair (not cooling, noise, water leak)', 449, '1.5 hr', 'fridge'),
        svc('gas', 'Gas refill', 1999, '2 hr', 'fridge'),
      ]},
      { id: 'washing', name: 'Washing Machine', icon: '🧺', services: [
        svc('install', 'Installation / Replacement', 399, '1 hr', 'machine'),
        svc('uninstall', 'Uninstallation', 249, '30 min', 'machine'),
        svc('repair', 'Repair (drum, drain, power)', 449, '1.5 hr', 'machine'),
      ]},
      { id: 'geyser', name: 'Geyser / Water heater', icon: '♨️', services: [
        svc('install', 'Installation / Replacement', 449, '1 hr', 'geyser'),
        svc('uninstall', 'Uninstallation', 249, '30 min', 'geyser'),
        svc('repair', 'Repair (no heating, leakage)', 349, '1 hr', 'geyser'),
      ]},
      { id: 'chimney', name: 'Kitchen Chimney', icon: '🍳', services: [
        svc('install', 'Installation / Replacement', 599, '1.5 hr', 'chimney'),
        svc('service', 'Service / Deep cleaning', 499, '1.5 hr', 'chimney'),
        svc('repair', 'Repair', 399, '1 hr', 'chimney'),
      ]},
      { id: 'microwave', name: 'Microwave Oven', icon: '🍲', services: [
        svc('repair', 'Repair (not heating, sparking, buttons)', 399, '1 hr', 'oven'),
      ]},
    ],
  },
  {
    id: 'plumbing',
    name: 'Plumber',
    icon: '🚰',
    color: '#06d6a0',
    tagline: 'Leaks, taps, toilets, pipes, tanks & motors',
    visitFee: 49,
    partsNote: 'Spare parts & materials (tap, pipe, flush kit, tank etc.) are extra and charged only after your approval.',
    hasInspection: true,
    bookingWindowDays: 14,
    minLeadHours: 1,
    slots: STANDARD_SLOTS,
    items: [
      { id: 'tap', name: 'Tap / Faucet & Shower', icon: '🚿', services: [
        svc('install', 'Installation / Replacement', 149, '20 min', 'tap'),
        svc('uninstall', 'Uninstallation', 99, '15 min', 'tap'),
        svc('repair', 'Repair / Leakage fix', 179, '30 min', 'tap'),
      ]},
      { id: 'leak', name: 'Water Leakage', icon: '💧', services: [
        svc('inspect', 'Leak detection & inspection', 249, '1 hr'),
        svc('repair', 'Leakage repair', 399, '1.5 hr', 'spot'),
      ]},
      { id: 'toilet', name: 'Toilet & Flush', icon: '🚽', services: [
        svc('install', 'Western / Indian toilet installation / Replacement', 1199, '2.5 hr', 'toilet'),
        svc('repair', 'Flush tank repair', 249, '45 min', 'toilet'),
        svc('block', 'Blockage removal', 399, '1 hr', 'toilet'),
      ]},
      { id: 'basin', name: 'Wash Basin & Kitchen Sink', icon: '🪣', services: [
        svc('install', 'Installation / Replacement', 499, '1.5 hr', 'basin'),
        svc('uninstall', 'Uninstallation', 249, '45 min', 'basin'),
        svc('block', 'Blockage removal', 299, '45 min', 'basin'),
      ]},
      { id: 'pipe', name: 'Pipe Fitting', icon: '🔧', services: [
        svc('new', 'New pipe fitting', 349, '1 hr', 'point'),
        svc('repair', 'Pipe repair / Replacement', 299, '1 hr', 'point'),
      ]},
      { id: 'tank', name: 'Water Tank', icon: '🛢️', services: [
        svc('clean', 'Tank cleaning', 599, '2 hr', 'tank'),
        svc('install', 'Tank replacement & installation (labour; new tank extra)', 799, '2.5 hr', 'tank'),
        svc('repair', 'Tank leakage / valve repair', 399, '1 hr', 'tank'),
      ]},
      { id: 'motor', name: 'Water Motor / Pump', icon: '⚙️', services: [
        svc('install', 'Installation / Replacement', 549, '1.5 hr', 'motor'),
        svc('uninstall', 'Uninstallation', 299, '45 min', 'motor'),
        svc('repair', 'Repair (not pumping, noise, auto-switch)', 449, '1.5 hr', 'motor'),
      ]},
    ],
  },
  {
    id: 'beauty',
    name: 'Bridal Makeup & Mehendi',
    icon: '💄',
    color: '#f72585',
    tagline: 'Bridal & party makeup, hairstyle, mehendi at home',
    visitFee: 0,
    partsNote: 'Hair extensions, special lenses or extra products (if you ask for them) are charged extra after your approval.',
    hasInspection: false,
    bookingWindowDays: 180, // weddings are booked months ahead
    minLeadHours: 24,       // at least one day's notice
    slots: BEAUTY_SLOTS,
    items: [
      { id: 'bridal', name: 'Bridal Makeup', icon: '👰', services: [
        svc('hd', 'HD bridal makeup + hairstyle + saree/lehenga draping', 14999, '3 hr'),
        svc('airbrush', 'Airbrush bridal makeup + hairstyle + draping', 19999, '3.5 hr'),
        svc('engagement', 'Engagement / Reception makeup + hairstyle', 8999, '2.5 hr'),
        svc('trial', 'Trial makeup session', 1999, '1.5 hr'),
      ]},
      { id: 'party', name: 'Party & Family Makeup', icon: '💃', services: [
        svc('makeup', 'Party makeup + hairstyle', 2499, '1.5 hr', 'person'),
        svc('hair', 'Hairstyle only', 799, '45 min', 'person'),
        svc('draping', 'Saree draping', 499, '20 min', 'person'),
      ]},
      { id: 'mehendi', name: 'Mehendi', icon: '🌿', services: [
        svc('bridal-full', 'Bridal mehendi: full hands & legs', 4999, '5 hr'),
        svc('bridal-hands', 'Bridal mehendi: hands only (up to elbow)', 2999, '3 hr'),
        svc('guest', 'Guest mehendi: both hands (front & back)', 499, '30 min', 'person'),
        svc('simple', 'Simple / Arabic design: one hand', 199, '15 min', 'person'),
      ]},
    ],
  },
];

// Each repair category gets an "inspection" option so customers can book an
// unlisted problem. The worker sets the real work + price on site, and the
// customer approves it. The inspection fee is then adjusted in the bill.
const INSPECTION_FEE = 199;
for (const cat of CATALOG) {
  if (!cat.hasInspection) continue;
  for (const item of cat.items) {
    item.services.push(svc('other', 'Something else / Not sure (inspection visit, describe in notes)', INSPECTION_FEE, '30 min', null, { kind: 'inspection' }));
  }
}

// ---------- price overrides from the Owner panel ----------
let overrides = {}; // key "cat.item.service" -> price, "cat.__visit" -> visit fee
function setOverrides(o) { overrides = o || {}; }

function priced(cat) {
  const visitKey = `${cat.id}.__visit`;
  return {
    ...cat,
    visitFee: overrides[visitKey] ?? cat.visitFee,
    items: cat.items.map(item => ({
      ...item,
      services: item.services.map(s => ({
        ...s,
        price: overrides[`${cat.id}.${item.id}.${s.id}`] ?? s.price,
      })),
    })),
  };
}

function getCatalog() { return CATALOG.map(priced); }

function getCategory(categoryId) {
  const c = CATALOG.find(x => x.id === categoryId);
  return c ? priced(c) : null;
}

function findService(categoryId, itemId, serviceId) {
  const category = getCategory(categoryId);
  if (!category) return null;
  const item = category.items.find(i => i.id === itemId);
  if (!item) return null;
  const service = item.services.find(s => s.id === serviceId);
  if (!service) return null;
  return { category, item, service };
}

module.exports = { getCatalog, getCategory, findService, setOverrides, CATEGORY_IDS: CATALOG.map(c => c.id) };
