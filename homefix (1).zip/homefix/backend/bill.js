// Builds the bill for a booking from its services, spare parts and fees.
//
// Inspection rule: if the customer booked "Something else" (inspection visit)
// and the worker then does real work that the customer approved, the
// inspection fee is shown and then ADJUSTED (subtracted), so the customer
// pays only for the work. If no other work is done, the inspection fee is paid.

function serviceLabel(s) {
  return `${s.itemName}: ${s.serviceName}`;
}

function computeBill(b) {
  const lines = [];
  let serviceTotal = 0;
  let hasRealWork = false;

  for (const s of b.services) {
    const amount = s.unitPrice * s.qty;
    serviceTotal += amount;
    if (s.kind !== 'inspection') hasRealWork = true;
    lines.push({
      type: s.kind === 'inspection' ? 'inspection' : 'service',
      label: serviceLabel(s),
      detail: s.unit ? `${s.qty} ${s.unit}${s.qty > 1 ? 's' : ''} × ₹${s.unitPrice}` : null,
      amount,
    });
  }

  // Inspection fee adjustment (booking started as an inspection, real work was approved)
  let adjustment = 0;
  if (b.inspectionFee > 0 && hasRealWork) {
    const realWork = b.services.filter(s => s.kind !== 'inspection').reduce((t, s) => t + s.unitPrice * s.qty, 0);
    lines.push({ type: 'inspection', label: 'Inspection visit', detail: null, amount: b.inspectionFee });
    adjustment = Math.min(b.inspectionFee, realWork);
    lines.push({ type: 'adjustment', label: 'Inspection fee adjusted in service charge', detail: null, amount: -adjustment });
    serviceTotal += b.inspectionFee - adjustment;
  }

  let partsTotal = 0;
  for (const p of b.parts || []) {
    partsTotal += p.price;
    lines.push({ type: 'part', label: `Spare part: ${p.name}`, detail: null, amount: p.price });
  }

  if (b.visitFee > 0) lines.push({ type: 'visit', label: 'Visit fee', detail: null, amount: b.visitFee });

  const total = serviceTotal + partsTotal + (b.visitFee || 0);
  return { lines, serviceTotal, partsTotal, visitFee: b.visitFee || 0, total };
}

function partnerEarning(bill, share) {
  return Math.round(bill.serviceTotal * share) + bill.partsTotal;
}

function summary(b) {
  return b.services.map(s => `${s.itemName}: ${s.serviceName}${s.qty > 1 ? ` ×${s.qty}` : ''}`).join(', ');
}

module.exports = { computeBill, partnerEarning, summary };
