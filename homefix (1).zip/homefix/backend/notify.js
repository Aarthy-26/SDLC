// Notifications: WhatsApp messages via the official WhatsApp Business Cloud API (Meta).
//
// Works without any setup: every message is saved in the database and shown
// in the Owner panel (Notifications tab) and printed in the server console.
//
// To really send on WhatsApp, set these environment variables:
//   WHATSAPP_TOKEN     - permanent access token from Meta (developers.facebook.com)
//   WHATSAPP_PHONE_ID  - the "Phone number ID" of your WhatsApp Business number
// Note: Meta only allows free-form messages within 24 hours of the customer
// messaging you. For other updates, Meta requires pre-approved "templates".

const db = require('./db');

const TOKEN = process.env.WHATSAPP_TOKEN;
const PHONE_ID = process.env.WHATSAPP_PHONE_ID;
const API_VERSION = process.env.WHATSAPP_API_VERSION || 'v20.0';

const whatsappEnabled = () => Boolean(TOKEN && PHONE_ID);

function toWhatsAppNumber(phone) {
  const digits = String(phone || '').replace(/\D/g, '');
  return digits.length === 10 ? '91' + digits : digits; // Indian numbers by default
}

async function sendWhatsApp(phone, text) {
  if (!whatsappEnabled()) return { sent: false, reason: 'WhatsApp not configured' };
  try {
    const res = await fetch(`https://graph.facebook.com/${API_VERSION}/${PHONE_ID}/messages`, {
      method: 'POST',
      headers: { Authorization: `Bearer ${TOKEN}`, 'Content-Type': 'application/json' },
      body: JSON.stringify({
        messaging_product: 'whatsapp',
        to: toWhatsAppNumber(phone),
        type: 'text',
        text: { body: text, preview_url: true },
      }),
    });
    const data = await res.json().catch(() => ({}));
    if (!res.ok) return { sent: false, reason: data.error?.message || `HTTP ${res.status}` };
    return { sent: true };
  } catch (err) {
    return { sent: false, reason: err.message };
  }
}

// Fire-and-forget: never blocks or breaks the booking flow.
function notify({ to, name, role, text, bookingRef }) {
  const entry = {
    id: db.id(), to, name, role, text, bookingRef: bookingRef || null,
    channel: 'whatsapp', status: whatsappEnabled() ? 'sending' : 'logged',
    at: new Date().toISOString(),
  };
  db.data.notifications.unshift(entry);
  db.data.notifications.length = Math.min(db.data.notifications.length, 500);
  db.save();
  console.log(`[notify → ${role} ${to}] ${text.replace(/\n/g, ' | ')}`);

  if (whatsappEnabled()) {
    sendWhatsApp(to, text).then(r => {
      entry.status = r.sent ? 'sent' : 'failed';
      if (!r.sent) entry.error = r.reason;
      db.save();
    });
  }
}

module.exports = { notify, sendWhatsApp, whatsappEnabled };
