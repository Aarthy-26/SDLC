const jwt = require('jsonwebtoken');
const db = require('./db');

const JWT_SECRET = process.env.JWT_SECRET || 'change-this-secret-in-production';
const TOKEN_TTL = '7d';

function signToken(user, role) {
  return jwt.sign({ sub: user.id, role }, JWT_SECRET, { expiresIn: TOKEN_TTL });
}

// Middleware factory: requireAuth('customer') or requireAuth('worker')
function requireAuth(role) {
  return (req, res, next) => {
    const header = req.headers.authorization || '';
    const token = header.startsWith('Bearer ') ? header.slice(7) : null;
    if (!token) return res.status(401).json({ error: 'Please log in to continue.' });
    try {
      const payload = jwt.verify(token, JWT_SECRET);
      if (payload.role !== role) return res.status(403).json({ error: 'Not allowed for this account type.' });
      const list = role === 'customer' ? db.data.customers : db.data.workers;
      const user = list.find(u => u.id === payload.sub);
      if (!user) return res.status(401).json({ error: 'Account not found. Please log in again.' });
      req.user = user;
      next();
    } catch {
      return res.status(401).json({ error: 'Session expired. Please log in again.' });
    }
  };
}

// Strip password hash before sending a user to the browser
function publicUser(u) {
  const { passwordHash, ...rest } = u;
  return rest;
}

module.exports = { signToken, requireAuth, publicUser };
