// Shared helpers for the customer website
const TOKEN_KEY = 'hf_customer_token';
const USER_KEY = 'hf_customer_user';

const Auth = {
  get token() { return localStorage.getItem(TOKEN_KEY); },
  get user() { try { return JSON.parse(localStorage.getItem(USER_KEY)); } catch { return null; } },
  save(token, user) { localStorage.setItem(TOKEN_KEY, token); localStorage.setItem(USER_KEY, JSON.stringify(user)); },
  clear() { localStorage.removeItem(TOKEN_KEY); localStorage.removeItem(USER_KEY); },
  logout() { this.clear(); location.href = '/'; },
  require() {
    if (!this.token) {
      location.href = '/login?next=' + encodeURIComponent(location.pathname + location.search);
      return false;
    }
    return true;
  },
};

async function api(path, { method = 'GET', body } = {}) {
  const headers = { 'Content-Type': 'application/json' };
  if (Auth.token) headers.Authorization = 'Bearer ' + Auth.token;
  const res = await fetch('/api' + path, { method, headers, body: body ? JSON.stringify(body) : undefined });
  let data = {};
  try { data = await res.json(); } catch { /* empty body */ }
  if (res.status === 401 && Auth.token) Auth.clear();
  if (!res.ok) throw new Error(data.error || 'Request failed');
  return data;
}

// Site configuration + catalog (loaded once per page)
let _config;
function getConfig() {
  if (!_config) _config = api('/catalog');
  return _config;
}

function esc(v) {
  return String(v ?? '').replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
}

const rupee = n => (n < 0 ? '−₹' : '₹') + Math.abs(Number(n || 0)).toLocaleString('en-IN');

function fmtDate(dateStr) {
  const d = new Date(dateStr + 'T00:00:00');
  return d.toLocaleDateString('en-IN', { weekday: 'short', day: 'numeric', month: 'short', year: 'numeric' });
}

function toast(msg, isError = false) {
  let t = document.getElementById('toast');
  if (!t) { t = document.createElement('div'); t.id = 'toast'; document.body.appendChild(t); }
  t.textContent = msg;
  t.className = 'show' + (isError ? ' error' : '');
  clearTimeout(t._timer);
  t._timer = setTimeout(() => { t.className = ''; }, 3500);
}

const STATUS_LABEL = {
  pending: 'Finding a professional',
  accepted: 'Professional assigned',
  on_the_way: 'On the way',
  in_progress: 'Work in progress',
  completed: 'Completed',
  cancelled: 'Cancelled',
};

function billHtml(bill, { title } = {}) {
  return `<div class="bill">
    ${title ? `<b>${esc(title)}</b>` : ''}
    ${bill.lines.map(l => `
      <div class="summary-row ${l.amount < 0 ? 'neg' : ''}">
        <span>${esc(l.label)}${l.detail ? `<br><small class="muted">${esc(l.detail)}</small>` : ''}</span>
        <span class="amt">${rupee(l.amount)}</span>
      </div>`).join('')}
    <div class="summary-row total"><span>Total</span><span>${rupee(bill.total)}</span></div>
  </div>`;
}

function renderHeader(active) {
  const user = Auth.user;
  document.getElementById('header').innerHTML = `
    <header class="site-header">
      <div class="container">
        <a href="/" class="logo"><img src="/shared/fixy.svg" alt="">HomeFix</a>
        <nav class="nav">
          <a href="/#services" class="hide-sm ${active === 'services' ? 'active' : ''}">Services</a>
          ${user ? `
            <a href="/bookings" class="${active === 'bookings' ? 'active' : ''}">My Bookings</a>
            <span class="user-chip hide-sm">Hi, ${esc(user.name.split(' ')[0])}</span>
            <a href="#" id="logoutBtn">Logout</a>
          ` : `
            <a href="/login" class="${active === 'login' ? 'active' : ''}">Login</a>
            <a href="/login?tab=signup" class="btn sm accent" style="color:#fff">Sign up</a>
          `}
        </nav>
      </div>
    </header>`;
  const lo = document.getElementById('logoutBtn');
  if (lo) lo.addEventListener('click', e => { e.preventDefault(); Auth.logout(); });
  initFloatingButtons();
}

function renderFooter() {
  const el = document.getElementById('footer');
  if (!el) return;
  getConfig().then(({ categories, settings }) => {
    el.innerHTML = `
      <footer class="site-footer">
        <div class="container">
          <div class="cols">
            <div>
              <a href="/" class="logo"><img src="/shared/fixy.svg" alt="">HomeFix</a>
              <p>Electricians, appliance experts, plumbers and bridal artists at your doorstep. Upfront prices, pay after the work.</p>
              ${settings.supportPhone ? `<p>📞 Support: <a href="tel:${esc(settings.supportPhone)}">${esc(settings.supportPhone)}</a></p>` : ''}
            </div>
            <div><h4>Services</h4><ul>${categories.map(c => `<li><a href="/service?cat=${c.id}">${c.icon} ${esc(c.name)}</a></li>`).join('')}</ul></div>
            <div><h4>Work with us</h4><ul>
              <li><a href="http://${location.hostname}:4000">Join as a partner →</a></li>
              <li><a href="/bookings">Track my booking</a></li>
            </ul></div>
          </div>
          <div class="small">© ${new Date().getFullYear()} ${esc(settings.businessName)} · Fixy is our helper mascot 🧰</div>
        </div>
      </footer>`;
  });
}

function modal(html, { wide = false } = {}) {
  const wrap = document.createElement('div');
  wrap.className = 'modal-backdrop';
  wrap.innerHTML = `<div class="modal ${wide ? 'wide' : ''}">${html}</div>`;
  wrap.addEventListener('click', e => { if (e.target === wrap) wrap.remove(); });
  document.body.appendChild(wrap);
  return wrap;
}

// ---------------- WhatsApp button + Fixy chat bot ----------------
const WA_ICON = '<svg viewBox="0 0 32 32" aria-hidden="true"><path d="M16 3C9 3 3.3 8.6 3.3 15.6c0 2.4.7 4.7 1.9 6.7L3 29l6.9-2.2c1.9 1 4 1.6 6.1 1.6 7 0 12.7-5.7 12.7-12.7S23 3 16 3zm0 23.1c-1.9 0-3.8-.5-5.4-1.5l-.4-.2-4.1 1.3 1.3-4-.3-.4a10.4 10.4 0 0 1-1.6-5.6C5.5 9.8 10.2 5.2 16 5.2s10.5 4.6 10.5 10.4S21.8 26.1 16 26.1zm5.8-7.8c-.3-.2-1.9-.9-2.2-1-.3-.1-.5-.2-.7.2-.2.3-.8 1-1 1.2-.2.2-.4.2-.7.1-.3-.2-1.3-.5-2.6-1.6-1-.9-1.6-1.9-1.8-2.2-.2-.3 0-.5.1-.7l.5-.6c.2-.2.2-.3.3-.6.1-.2 0-.4 0-.6l-1-2.4c-.3-.6-.5-.5-.7-.5h-.6c-.2 0-.6.1-.9.4-.3.3-1.2 1.1-1.2 2.8s1.2 3.2 1.4 3.5c.2.2 2.4 3.6 5.7 5 .8.3 1.4.5 1.9.7.8.3 1.5.2 2.1.1.6-.1 1.9-.8 2.2-1.5.3-.7.3-1.4.2-1.5-.1-.2-.3-.3-.6-.4z"/></svg>';

function initFloatingButtons() {
  if (document.querySelector('.fab-stack')) return;
  const stack = document.createElement('div');
  stack.className = 'fab-stack';
  document.body.appendChild(stack);
  getConfig().then(({ settings }) => {
    if (settings.whatsappNumber) {
      const wa = document.createElement('a');
      wa.className = 'fab wa';
      wa.href = `https://wa.me/${encodeURIComponent(settings.whatsappNumber)}?text=${encodeURIComponent('Hi HomeFix, I need help with a service.')}`;
      wa.target = '_blank'; wa.rel = 'noopener';
      wa.title = 'Chat with us on WhatsApp';
      wa.innerHTML = WA_ICON;
      stack.prepend(wa);
    }
  });
  const botBtn = document.createElement('button');
  botBtn.className = 'fab bot';
  botBtn.title = 'Ask Fixy';
  botBtn.innerHTML = '<img src="/shared/fixy.svg" alt="Ask Fixy"><span class="fab-label">Ask Fixy 👋</span>';
  botBtn.onclick = () => toggleChat();
  stack.appendChild(botBtn);
  setTimeout(() => botBtn.querySelector('.fab-label')?.remove(), 8000);
}

const chatState = { history: [], open: false };

function toggleChat(prefill) {
  let panel = document.getElementById('chatPanel');
  if (panel && !prefill) { panel.remove(); chatState.open = false; return; }
  if (!panel) {
    panel = document.createElement('div');
    panel.id = 'chatPanel';
    panel.className = 'chat-panel';
    panel.innerHTML = `
      <div class="chat-head">
        <img src="/shared/fixy.svg" alt="">
        <div><b>Fixy</b><small>HomeFix assistant · replies instantly</small></div>
        <button type="button" aria-label="Close">✕</button>
      </div>
      <div class="chat-body" id="chatBody"></div>
      <div class="chat-chips">
        ${['Fan not working', 'AC not cooling', 'Water leakage', 'Bridal mehendi price', 'How do I pay?'].map(c => `<button type="button">${c}</button>`).join('')}
      </div>
      <form class="chat-form"><input placeholder="Type your problem…" maxlength="500" autocomplete="off"><button class="btn" type="submit">Send</button></form>`;
    document.body.appendChild(panel);
    panel.querySelector('.chat-head button').onclick = () => toggleChat();
    panel.querySelectorAll('.chat-chips button').forEach(b => b.onclick = () => sendChat(b.textContent));
    panel.querySelector('form').onsubmit = e => {
      e.preventDefault();
      const inp = e.target.querySelector('input');
      if (inp.value.trim()) { sendChat(inp.value.trim()); inp.value = ''; }
    };
    chatState.open = true;
    if (!chatState.history.length) {
      chatState.history.push({ role: 'bot', text: 'Hi! 👋 I\'m Fixy. Tell me what\'s broken at home, or ask about bridal makeup & mehendi. I\'ll show you prices and help you book.' });
    }
    renderChat();
  }
  if (prefill) sendChat(prefill);
  panel.querySelector('input').focus();
}

function renderChat(typing = false) {
  const body = document.getElementById('chatBody');
  if (!body) return;
  body.innerHTML = chatState.history.map(m => `
    <div class="msg ${m.role}">${esc(m.text)}</div>
    ${m.links?.length ? `<div class="msg-links">${m.links.map(l => `<a href="${esc(l.url)}">${esc(l.label)}</a>`).join('')}</div>` : ''}`).join('') +
    (typing ? '<div class="msg bot typing"><span></span><span></span><span></span></div>' : '');
  body.scrollTop = body.scrollHeight;
}

async function sendChat(text) {
  chatState.history.push({ role: 'user', text });
  renderChat(true);
  try {
    const history = chatState.history.filter((m, i) => i > 0).map(m => ({ role: m.role, text: m.text }));
    const { reply, links } = await api('/chat', { method: 'POST', body: { history } });
    chatState.history.push({ role: 'bot', text: reply, links });
  } catch (err) {
    chatState.history.push({ role: 'bot', text: err.message || 'Sorry, something went wrong. Please try again.' });
  }
  renderChat();
}
