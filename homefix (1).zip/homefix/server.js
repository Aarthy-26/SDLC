// Starts all THREE websites, sharing one backend (same database + API):
//   Customer website  -> http://localhost:3000
//   Partner website   -> http://localhost:4000
//   Owner panel       -> http://localhost:5000

const express = require('express');
const path = require('path');
const db = require('./backend/db');
const { setOverrides } = require('./backend/catalog');
setOverrides(db.data.priceOverrides); // apply owner price changes before anything else

const api = require('./backend/api');
const adminApi = require('./backend/admin-api');

const CUSTOMER_PORT = Number(process.env.CUSTOMER_PORT) || 3000;
const WORKER_PORT = Number(process.env.WORKER_PORT) || 4000;
const ADMIN_PORT = Number(process.env.ADMIN_PORT) || 5000;

function createSite(folder, { admin = false } = {}) {
  const app = express();
  app.disable('x-powered-by');
  app.set('trust proxy', 1);
  app.use(express.json({ limit: '100kb' }));
  app.use((req, res, next) => {
    res.setHeader('X-Content-Type-Options', 'nosniff');
    res.setHeader('X-Frame-Options', 'DENY');
    res.setHeader('Referrer-Policy', 'strict-origin-when-cross-origin');
    next();
  });
  if (admin) app.use('/api/admin', adminApi);
  app.use('/api', api);
  app.use('/api', (req, res) => res.status(404).json({ error: 'Not found' }));
  // shared images (mascot etc.)
  app.use('/shared', express.static(path.join(__dirname, 'shared')));
  // map library for the owner panel's live map (bundled, no CDN needed)
  if (admin) app.use('/vendor/leaflet', express.static(path.join(__dirname, 'node_modules', 'leaflet', 'dist')));
  app.use(express.static(path.join(__dirname, folder), { extensions: ['html'] }));
  app.use((req, res) => res.status(404).sendFile(path.join(__dirname, folder, 'index.html')));
  // eslint-disable-next-line no-unused-vars
  app.use((err, req, res, next) => {
    console.error(err);
    res.status(err.status || 500).json({ error: err.type === 'entity.parse.failed' ? 'Invalid request.' : 'Something went wrong.' });
  });
  return app;
}

createSite('customer-site').listen(CUSTOMER_PORT, () =>
  console.log(`Customer website running at  http://localhost:${CUSTOMER_PORT}`));
createSite('worker-site').listen(WORKER_PORT, () =>
  console.log(`Partner website running at   http://localhost:${WORKER_PORT}`));
createSite('admin-site', { admin: true }).listen(ADMIN_PORT, () =>
  console.log(`Owner panel running at       http://localhost:${ADMIN_PORT}`));

if (!process.env.ADMIN_PASSWORD) console.log('⚠  Owner login is admin / admin123 — set ADMIN_USERNAME and ADMIN_PASSWORD before going live.');
if (!process.env.ANTHROPIC_API_KEY) console.log('ℹ  Chat bot is using built-in answers. Set ANTHROPIC_API_KEY for the AI assistant.');
if (!process.env.WHATSAPP_TOKEN) console.log('ℹ  WhatsApp not connected: messages are logged in the Owner panel. See README to connect.');
