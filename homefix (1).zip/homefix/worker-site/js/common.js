// Shared helpers for the partner website
const TOKEN_KEY = 'hf_worker_token';
const USER_KEY = 'hf_worker_user';

const Auth = {
  get token() { return localStorage.getItem(TOKEN_KEY); },
  get user() { try { return JSON.parse(localStorage.getItem(USER_KEY)); } catch { return null; } },
  save(token, user) { localStorage.setItem(TOKEN_KEY, token); localStorage.setItem(USER_KEY, JSON.stringify(user)); },
  setUser(user) { localStorage.setItem(USER_KEY, JSON.stringify(user)); },
  clear() { localStorage.removeItem(TOKEN_KEY); localStorage.removeItem(USER_KEY); },
  logout() { this.clear(); location.href = '/'; },
  require() { if (!this.token) { location.href = '/login'; return false; } return true; },
};

async function api(path, { method = 'GET', body } = {}) {
  const headers = { 'Content-Type': 'application/json' };
  if (Auth.token) headers.Authorization = 'Bearer ' + Auth.token;
  const res = await fetch('/api' + path, { method, headers, body: body ? JSON.stringify(body) : undefined });
  let data = {};
  try { data = await res.json(); } catch { /* empty body */ }
  if (res.status === 401 && Auth.token) { Auth.clear(); location.href = '/login'; }
  if (!res.ok) throw new Error(data.error || 'Request failed');
  return data;
}

let _config;
function getConfig() { if (!_config) _config = api('/catalog'); return _config; }

function esc(v) {
  return String(v ?? '').replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
}
const rupee = n => (n < 0 ? '−₹' : '₹') + Math.abs(Number(n || 0)).toLocaleString('en-IN');
function fmtDate(dateStr) {
  return new Date(dateStr + 'T00:00:00').toLocaleDateString('en-IN', { weekday: 'short', day: 'numeric', month: 'short' });
}

function toast(msg, isError = false) {
  let t = document.getElementById('toast');
  if (!t) { t = document.createElement('div'); t.id = 'toast'; document.body.appendChild(t); }
  t.textContent = msg;
  t.className = 'show' + (isError ? ' error' : '');
  clearTimeout(t._timer);
  t._timer = setTimeout(() => { t.className = ''; }, 3500);
}

const STATUS_LABEL = {
  pending: 'Open', accepted: 'Accepted', on_the_way: 'On the way',
  in_progress: 'In progress', completed: 'Completed', cancelled: 'Cancelled',
};

// Bill without amounts when the owner hides them
function billHtml(bill, { title, showAmounts = true } = {}) {
  return `<div class="bill">
    ${title ? `<b>${esc(title)}</b>` : ''}
    ${bill.lines.map(l => `
      <div class="summary-row ${l.amount < 0 ? 'neg' : ''}">
        <span>${esc(l.label)}${l.detail ? `<br><small class="muted">${esc(showAmounts ? l.detail : l.detail.replace(/×.*/, ''))}</small>` : ''}</span>
        ${showAmounts && l.amount !== undefined ? `<span class="amt">${rupee(l.amount)}</span>` : ''}
      </div>`).join('')}
    ${showAmounts && bill.total !== undefined ? `<div class="summary-row total"><span>Collect from customer</span><span>${rupee(bill.total)}</span></div>` : ''}
  </div>`;
}

function renderHeader(active) {
  const user = Auth.user;
  document.getElementById('header').innerHTML = `
    <header class="site-header">
      <div class="container">
        <a href="${user ? '/dashboard' : '/'}" class="logo"><img src="/shared/fixy.svg" alt="">HomeFix<small>Partner</small></a>
        <nav class="nav">
          ${user ? `
            <span class="user-chip hide-sm">${esc(user.name)}</span>
            <a href="/dashboard" class="${active === 'dashboard' ? 'active' : ''}">Dashboard</a>
            <a href="#" id="logoutBtn">Logout</a>
          ` : `
            <a href="/login" class="${active === 'login' ? 'active' : ''}">Login</a>
            <a href="/login?tab=enroll" class="btn sm accent" style="color:#fff">Join now</a>
          `}
        </nav>
      </div>
    </header>`;
  const lo = document.getElementById('logoutBtn');
  if (lo) lo.addEventListener('click', e => { e.preventDefault(); Auth.logout(); });

  // WhatsApp support button
  getConfig().then(({ settings }) => {
    if (!settings.whatsappNumber || document.querySelector('.fab-stack')) return;
    const stack = document.createElement('div');
    stack.className = 'fab-stack';
    stack.innerHTML = `<a class="fab wa" target="_blank" rel="noopener" title="Partner support on WhatsApp"
      href="https://wa.me/${encodeURIComponent(settings.whatsappNumber)}?text=${encodeURIComponent('Hi HomeFix, I am a partner and need help.')}">
      <svg viewBox="0 0 32 32"><path d="M16 3C9 3 3.3 8.6 3.3 15.6c0 2.4.7 4.7 1.9 6.7L3 29l6.9-2.2c1.9 1 4 1.6 6.1 1.6 7 0 12.7-5.7 12.7-12.7S23 3 16 3zm5.8 15.3c-.3-.2-1.9-.9-2.2-1-.3-.1-.5-.2-.7.2-.2.3-.8 1-1 1.2-.2.2-.4.2-.7.1-.3-.2-1.3-.5-2.6-1.6-1-.9-1.6-1.9-1.8-2.2-.2-.3 0-.5.1-.7l.5-.6c.2-.2.2-.3.3-.6.1-.2 0-.4 0-.6l-1-2.4c-.3-.6-.5-.5-.7-.5h-.6c-.2 0-.6.1-.9.4-.3.3-1.2 1.1-1.2 2.8s1.2 3.2 1.4 3.5c.2.2 2.4 3.6 5.7 5 .8.3 1.4.5 1.9.7.8.3 1.5.2 2.1.1.6-.1 1.9-.8 2.2-1.5.3-.7.3-1.4.2-1.5-.1-.2-.3-.3-.6-.4z"/></svg></a>`;
    document.body.appendChild(stack);
  });
}

function renderFooter() {
  const el = document.getElementById('footer');
  if (!el) return;
  el.innerHTML = `
    <footer class="site-footer"><div class="container row">
      <span>© ${new Date().getFullYear()} HomeFix Partner · Grow your work with us</span>
      <span class="spacer"></span>
      <span>Need a service at home? <a href="http://${location.hostname}:3000">Book as a customer →</a></span>
    </div></footer>`;
}

function modal(html, { wide = false } = {}) {
  const wrap = document.createElement('div');
  wrap.className = 'modal-backdrop';
  wrap.innerHTML = `<div class="modal ${wide ? 'wide' : ''}">${html}</div>`;
  wrap.addEventListener('click', e => { if (e.target === wrap) wrap.remove(); });
  document.body.appendChild(wrap);
  return wrap;
}
