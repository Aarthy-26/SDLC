# HomeFix: Doorstep Home Services Platform (v2)

Three websites sharing one backend:

| Website | URL | Who uses it |
|---|---|---|
| **Customer website** | http://localhost:3000 | Book an electrician, appliance repair, plumber, or bridal makeup & mehendi. Choose quantity, see the price, pick a slot, pin your location, approve updated bills, track the professional, rate. Includes the **Fixy chat bot** and **WhatsApp button**. |
| **Partner website** | http://localhost:4000 | Workers enroll, get approved, go online (shares live location), accept jobs, enter the start code, **update work / add spare parts** for customer approval, complete or **cancel** jobs. |
| **Owner panel** | http://localhost:5000 | **Live map** of partners & customers, all bookings (assign / cancel), **approve or block partners**, customers, **change prices**, settings, WhatsApp message log. |

## Run it (Windows / Mac / Linux)

Requires **Node.js 18+**.

```bash
cd homefix
npm install
npm start
```

Owner login: **admin / admin123** (change it, see "Before going live").

Try the full flow:
1. **Partner site:** enroll, ticking a skill.
2. **Owner panel:** Partners tab → **Approve**.
3. **Customer site:** sign up → Electrician → Lights → Installation → set quantity to 3 → pick a slot → **Book**.
4. **Partner:** Accept → Start travelling → Enter start code → **Update work / add spare parts** → send.
5. **Customer:** My Bookings → **Approve new bill**.
6. **Partner:** Mark completed. **Customer:** rate. **Owner:** check the Live map and Notifications.

> Upgrading from v1? The old database format is backed up automatically to `data/db.v1.backup.json` and a fresh database is started.

## What changed in v2

| # | Change |
|---|---|
| 1, 16 | **Carpenter removed completely** (no doors, no furniture). |
| 2 | **Partner updates the work on site** (e.g. a "Something else" booking turns out to be a different problem). The customer must approve the new bill on their phone before the partner can complete the job. |
| 3 | Regulator replacement moved into **Fan → Repair**. |
| 4 | Prices are **per item** (per fan, per light, per tap…) with a **quantity selector**. Flat-price jobs say "per job". |
| 5 | MCB shown as **MCB (Miniature Circuit Breaker) / Fuse**. |
| 6 | **"Installation / Replacement"** everywhere. |
| 7 | **Water Tank:** cleaning, replacement & installation, leakage/valve repair. **Water Motor** is a separate item. |
| 8 | Partner earnings are **hidden** by default. The owner can choose in Settings whether partners see "your earning" and/or "amount to collect". |
| 9 | Partner **Cancel job**: "I can't come" gives the job to another partner. Customer not available / not reachable / wrong address / refused / other cancels the booking and informs the customer. |
| 10 | New design with **Fixy**, an original mascot, plus animations, FAQ, and real customer reviews (shown only once real ratings exist). |
| 11 | **Fixy chat bot** on the customer site, **WhatsApp chat button**, **WhatsApp notifications**, and a **WhatsApp bot** webhook. |
| 12 | **Spare parts are extra**: shown on every service; partners add them with a price and the customer approves. |
| 13 | **Live location**: partners share it while online; customers can pin their location when booking; the owner sees everything on a live map. Customers can see where their professional is while they're on the way. |
| 14 | **Inspection fee adjusted**: if the customer approves real work after a ₹199 inspection, the bill shows the fee and then subtracts it. |
| 15 | **Bridal Makeup & Mehendi** category: bridal HD/airbrush, engagement, trial, party makeup per person, bridal & guest mehendi. Bookable up to 6 months ahead, at least 1 day before, with early-morning slots from 4 AM. No visit fee. |
| + | **Owner panel**: partner approval, manual assignment, price editor, settings, message log. |

## Connect WhatsApp (optional)

Without setup, every message (booking confirmed, partner on the way, approve the bill, etc.) is **saved in Owner panel → Notifications**, so nothing breaks.

To send real WhatsApp messages you need the **WhatsApp Business Cloud API** from Meta. Sign up yourself at developers.facebook.com, or through a provider such as Interakt, AiSensy, Gupshup or Twilio. You'll need your business documents.

Set these environment variables before `npm start`:

```powershell
# PowerShell
$env:WHATSAPP_TOKEN="your-permanent-access-token"
$env:WHATSAPP_PHONE_ID="your-phone-number-id"
$env:WHATSAPP_VERIFY_TOKEN="any-secret-word"          # for the WhatsApp bot webhook
$env:PUBLIC_CUSTOMER_URL="https://your-domain.com"     # so bot replies include booking links
npm start
```

- **WhatsApp bot (customers chat on WhatsApp):** in the Meta dashboard, set the webhook URL to `https://your-domain.com/api/whatsapp/webhook` with the same verify token, and subscribe to `messages`. It needs a public HTTPS address, so it won't work on localhost.
- **Message templates:** Meta allows free-form messages only within 24 hours of the customer's last message. For other updates (e.g. "partner on the way"), Meta requires pre-approved **message templates**. Create templates for these messages in Meta, then change `sendWhatsApp` in `backend/notify.js` to send `type: "template"`.
- **WhatsApp chat button:** just enter your number in Owner panel → Settings. No API needed.

## Connect the AI assistant (optional)

Fixy works out of the box with built-in answers (prices, timings, payment, cancellation, spare parts). For natural AI conversation in any language, set an Anthropic API key (paid per use):

```powershell
$env:ANTHROPIC_API_KEY="sk-ant-..."
npm start
```

The AI only answers from your real price list. The same brain also answers WhatsApp bot messages.

## Live location: how it works and its limits

- **Partners:** location is shared from the partner website while they are **online**. Phone browsers pause it when the screen is off or the browser is in the background. Reliable all-day tracking needs a mobile app.
- **Customers:** a one-time map pin when booking. Customers are not tracked live.
- **Browsers only allow location on `https://` sites or `localhost`.** If you open the site on a phone using your computer's IP address (http://192.168…), location will be blocked. Deploy with HTTPS for real use.
- The owner map uses OpenStreetMap (free) and needs internet for the map tiles.

## Project structure

```
homefix/
├── server.js                # starts all 3 websites (ports 3000, 4000, 5000)
├── backend/
│   ├── catalog.js           # categories, items, services & default prices  ← edit here
│   ├── api.js               # customer + partner API (bookings, approvals, cancel, location, chat)
│   ├── admin-api.js         # owner API (overview, live map, partners, prices, settings)
│   ├── bill.js              # bill calculation (quantity, spare parts, inspection adjustment)
│   ├── bot.js               # Fixy assistant (built-in + optional Claude AI)
│   ├── notify.js            # WhatsApp notifications (logged if not connected)
│   ├── auth.js, db.js       # login tokens, JSON-file database (data/db.json)
├── shared/fixy.svg          # mascot
├── customer-site/           # index, login, service (booking), bookings
├── worker-site/             # index, login (enroll), dashboard
└── admin-site/              # login, index (owner panel)
```

## Before going live

- Set `ADMIN_USERNAME`, `ADMIN_PASSWORD` and a long random `JWT_SECRET`.
- Deploy with **HTTPS** on real domains, e.g. `homefix.in`, `partner.homefix.in`, `admin.homefix.in`. Update the partner/customer links in the footers (they currently point to ports 3000/4000).
- Replace the JSON database (`backend/db.js`) with PostgreSQL or MySQL once you have real traffic.
- Optional next steps: online payments (Razorpay), SMS OTP login, partner photo/ID document upload, and a mobile app for background location.
